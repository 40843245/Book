package main;

import fileexample1.FileExample1;
import fileutil.FileUtil;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        var path1 = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14\\FileExample1\\src\\main\\Main.java";
        var path2 = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14\\FileExample1\\src\\main\\Main.java";
        FileExample1.printIsSameFile(path1,path2);
    }
}
