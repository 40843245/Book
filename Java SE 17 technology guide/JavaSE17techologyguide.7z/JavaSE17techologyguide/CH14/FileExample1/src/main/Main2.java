package main;

import fileexample1.FileExample1;

import java.io.IOException;

public class Main2 {
    public static void main(String[] args) throws IOException {
        var path1 = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14\\FileExample1\\src\\main\\FileNotFound.java";
        var path2 = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14\\FileExample1\\src\\main\\FileNotFound.java";
        FileExample1.printIsSameFile(path1,path2);
    }
}
