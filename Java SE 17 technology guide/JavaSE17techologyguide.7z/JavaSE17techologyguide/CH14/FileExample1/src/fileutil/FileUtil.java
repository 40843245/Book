package fileutil;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class FileUtil {
    public static boolean isSameFile(Path path1, Path path2) throws IOException {
        return Files.exists(path1) && Files.exists(path2) && Files.isSameFile(path1,path2);
    }

    public static boolean pathExists(Path path1){
        return Files.exists(path1);
    }

    public static boolean pathNotExists(Path path1){
        return Files.notExists(path1);
    }
}
