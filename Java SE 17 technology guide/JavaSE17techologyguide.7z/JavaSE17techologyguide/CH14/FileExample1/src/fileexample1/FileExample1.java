package fileexample1;

import fileutil.FileUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileExample1 {
    public static void printIsSameFile(String pathName1,String pathName2) throws IOException {
        var path1 = Paths.get(pathName1);
        var path2 = Paths.get(pathName2);
        FileExample1.printIsSameFile(path1,path2);
    }

    public static void printIsSameFile(Path path1,Path path2) throws IOException {
        System.out.printf("Does path1:`%s` exists?`%b`.%n",path1.toString(),FileUtil.pathExists(path1));
        System.out.printf("Does path1:`%s` exists?`%b`.%n",path2.toString(),FileUtil.pathExists(path2));
        System.out.printf("Is path1:`%s` same as path2:`%s`?`%b`.%n",path1.toString(),path2.toString(), Files.isSameFile(path1,path2)); // WTF
        System.out.printf("Is path1:`%s` same as path2:`%s`?`%b`.%n",path1.toString(),path2.toString(),FileUtil.isSameFile(path1,path2)); // WTF
    }
}
