# FileExample1.java
## intro
An example to illustrate the behaviour of method in `File` and `Files` class.

## Examples
### Example 1
```
var path1 = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14\\FileExample1\\src\\main\\Main.java";
        var path2 = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14\\FileExample1\\src\\main\\Main.java";
        FileExample1.printIsSameFile(path1,path2);
```
#### Input
#### Output
```
"C:\Program Files\Android\Android Studio\jbr\bin\java.exe" "-javaagent:C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2024.2.0.2\lib\idea_rt.jar=65511:C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2024.2.0.2\bin" -Dfile.encoding=UTF-8 -classpath C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\out\production\FileExample1 main.Main
Does path1:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\Main.java` exists?`true`.
Does path1:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\Main.java` exists?`true`.
Is path1:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\Main.java` same as path2:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\Main.java`?`true`.
Is path1:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\Main.java` same as path2:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\Main.java`?`true`.

Process finished with exit code 0
```

### Example 2
#### Input
```
        var path1 = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14\\FileExample1\\src\\main\\FileNotFound.java";
        var path2 = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14\\FileExample1\\src\\main\\FileNotFound.java";
        FileExample1.printIsSameFile(path1,path2);
```
#### Output
```
"C:\Program Files\Android\Android Studio\jbr\bin\java.exe" "-javaagent:C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2024.2.0.2\lib\idea_rt.jar=65516:C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2024.2.0.2\bin" -Dfile.encoding=UTF-8 -classpath C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\out\production\FileExample1 main.Main2
Does path1:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\FileNotFound.java` exists?`false`.
Does path1:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\FileNotFound.java` exists?`false`.
Is path1:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\FileNotFound.java` same as path2:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\FileNotFound.java`?`true`.
Is path1:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\FileNotFound.java` same as path2:`C:\Users\40843\OneDrive\桌面\TibaMe\Java\JavaSE17techologyguide\CH14\FileExample1\src\main\FileNotFound.java`?`false`.

Process finished with exit code 0
```

## WTF

1. In Example 2, why `Files.isSameFile(path1,path2));` returns true?

While why `FileUtil.isSameFile(path1,path2);` returns false?

where `FileUtil.isSameFile` is defined in `FileUtil` as follows.

```
public static boolean isSameFile(Path path1, Path path2) throws IOException {
        return Files.exists(path1) && Files.exists(path2) && Files.isSameFile(path1,path2);
    }
```

The reason of `Files.isSameFile(path1,path2));` returns true is that

`Files.isSameFile(path1,path2)` only check the path1 and path2 are equivalent, **NOT** check the path1 and path2 exist or not.

> [!TIP]
> You can find suprising fact on page 14-12 of the book `Java SE 17技術手冊`

While my defined `FileUtil.isSameFile(path1,path2);` NOT only checks the path1 and path2 are equivalent, but also checks the path1 and path2 exist or not.