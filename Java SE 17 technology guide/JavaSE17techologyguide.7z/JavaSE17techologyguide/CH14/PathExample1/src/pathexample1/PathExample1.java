package pathexample1;

import java.nio.file.Path;
import java.nio.file.Paths;

public class PathExample1 {

    public static void printOnePathInfo(String pathName1){
        var path1 = Paths.get(pathName1);
        PathExample1.printOnePathInfo(path1);
    }

    public static void printOnePathInfo(Path path1){
        System.out.println("---------------------------------");
        System.out.printf("All infos about path1:%s.%n",path1.toString());

        System.out.printf("path1.toString():%s%n",path1.toString());
        System.out.printf("path1.toUri():%s%n",path1.toUri());
        System.out.printf("path1.getFileName():%s%n",path1.getFileName());
        System.out.printf("path1.getFileSystem():%s%n",path1.getFileSystem());
        System.out.printf("path1.getParent():%s%n",path1.getParent());
        System.out.printf("path1.getRoot():%s%n",path1.getRoot());
        System.out.printf("path1.getClass():%s%n",path1.getClass());

        System.out.println("---------------------------------");
        System.out.printf("All infos about children in path1:%s.%n",path1.toString());
        PathExample1.printAllPassedNodesInfo(path1);
    }

    public static void printAllPassedNodesInfo(Path path1){
        var path1Depth = path1.getNameCount();
        System.out.printf("path1 is in %d depth compared to the root of system.%n",path1Depth);
        for(var i=0;i<path1Depth;i++){
            var childrenPath = path1.getName(i);
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.printf("childrenPath.toString():%s%n",childrenPath.toString());
        }

        if(path1Depth>=1){
            var subpath1 = path1.subpath(0,path1Depth-1);
            System.out.println("#######################");
            System.out.printf("path1.subpath(0,%d-1):%s%n",path1Depth,subpath1);
        }

        var subpath2 = path1.subpath(0,path1Depth);
        System.out.println("#######################");
        System.out.printf("path1.subpath(0,%d):%s%n",path1Depth,subpath2);
    }

    public static void printRelationOfTwoPathsInfo(String pathName1,String pathName2){
        var path1 = Paths.get(pathName1);
        var path2 = Paths.get(pathName2);
        PathExample1.printRelationOfTwoPathsInfo(path1,path2);
    }

    public static void printRelationOfTwoPathsInfo(Path path1, Path path2){

        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        System.out.printf("Is the path1:`%s` equal to path2:`%s`?`%b`.%n",path1.toString(),path2.toString(),path1.equals(path2));
        System.out.printf("path1.compareTo(path2):%d.%n",path1.compareTo(path2));

        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        System.out.printf("Let's get the relative path of path1:`%s` and path2:`%s`.%n",path1,path2);
        var relativePathFromPath1ToPath2 = path1.relativize(path2);
        PathExample1.printOnePathInfo(relativePathFromPath1ToPath2.normalize());

        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        System.out.printf("Let's get the resolved path of path1:`%s` and path2:`%s`.%n",path1,path2);
        var resolvedPathFromPath1ToPath2 = path1.resolve(path2);
        PathExample1.printOnePathInfo(resolvedPathFromPath1ToPath2.normalize());

        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        System.out.printf("Let's get the resolved sibling path of path1:`%s` and path2:`%s`.%n",path1,path2);
        var resolvedSliblingPathFromPath1ToPath2 = path1.resolve(path2);
        PathExample1.printOnePathInfo(resolvedSliblingPathFromPath1ToPath2.normalize());
    }

    public static void printOnePathOtherInfo(String pathName1,String startWith,String endsWith){
        var path1 = Paths.get(pathName1);
        PathExample1.printOnePathOtherInfo(path1,startWith,endsWith);
    }

    public static void printOnePathOtherInfo(Path path1,String startWith,String endsWith){
        System.out.printf("Does the path1:`%s` start with `%s`?`%b`.%n",path1,startWith,path1.startsWith(startWith));
        System.out.printf("Does the path1:`%s` end with `%s`?`%b`.%n",path1,endsWith,path1.endsWith(endsWith));
    }
}
