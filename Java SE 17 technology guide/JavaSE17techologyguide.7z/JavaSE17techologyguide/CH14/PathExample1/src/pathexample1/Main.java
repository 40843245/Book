package pathexample1;

public class Main {
    public static void main(String[] args){
        var pathName1="C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14";
        PathExample1.printOnePathInfo(pathName1);
    }
}
