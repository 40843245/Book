package pathexample1;

public class Main3 {
    public static void main(String[] args) {
        var pathName1="C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14";
        var startsWith = "C:\\";
        var endsWith = "CH14";

        PathExample1.printOnePathOtherInfo(pathName1,startsWith,endsWith);
    }
}
