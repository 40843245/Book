package pathexample1;

public class Main4 {
    public static void main(String[] args) {
        var userhomePath = System.getProperty("user.home");
        System.out.printf("The user home in this device is located at `%s`.%n",userhomePath);
    }
}