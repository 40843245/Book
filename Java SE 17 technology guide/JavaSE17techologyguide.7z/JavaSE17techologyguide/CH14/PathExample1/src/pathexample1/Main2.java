package pathexample1;

public class Main2 {
    public static void main(String[] args){
        var pathName1="C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14";
        var pathName2="C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH12";

        PathExample1.printRelationOfTwoPathsInfo(pathName1,pathName2);
    }
}
