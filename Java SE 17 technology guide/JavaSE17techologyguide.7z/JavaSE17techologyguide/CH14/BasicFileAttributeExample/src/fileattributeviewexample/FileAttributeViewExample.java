package fileattributeviewexample;

import basicfileattributeexample.BasicFileAttributeExample;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttributeView;

public class FileAttributeViewExample {
    public static void printFileAttributeViewInfo(String pathName1) throws IOException {
        var path1 = Paths.get(pathName1);
        FileAttributeViewExample.printFileAttributeViewInfo(path1);
    }

    public static void printFileAttributeViewInfo(Path path1) throws IOException {
        System.out.printf("All info about file attribute view of the path1:`%s`.%n",path1.toString());
        FileAttributeView view = Files.getFileAttributeView(path1, FileAttributeView.class);
        try {
            System.out.printf("view:`%s`name is`%s`.%n", view, view.name());
        }catch (Exception ex){
            System.out.println("The view is null.");
        }
    }
}
