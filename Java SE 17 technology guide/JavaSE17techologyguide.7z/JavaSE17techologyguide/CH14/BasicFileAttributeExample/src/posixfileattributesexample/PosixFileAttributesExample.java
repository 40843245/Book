package posixfileattributesexample;

import fileattributeviewexample.FileAttributeViewExample;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.DosFileAttributes;
import java.nio.file.attribute.PosixFileAttributes;

public class PosixFileAttributesExample {
    public static void printPosixFileAttributesInfo(String pathName1) throws IOException {
        var path1 = Paths.get(pathName1);
        PosixFileAttributesExample.printPosixFileAttributesInfo(path1);
    }

    public static void printPosixFileAttributesInfo(Path path1) throws IOException {
        System.out.printf("All info about posix file attributes of the path1:`%s`.%n",path1.toString());
        PosixFileAttributes attrs = Files.readAttributes(path1, PosixFileAttributes.class);
        System.out.printf("The group owner of path1:`%s` is `%s``.%n",path1,attrs.group().toString());
        System.out.printf("The owner of path1:`%s` is `%s``.%n",path1,attrs.owner().toString());

        System.out.printf("path1:`%s` has these permissions.",path1);
        var permissions = attrs.permissions();
        for(var permission : permissions) {
            System.out.print(permission.toString().concat("\t"));
        }
        System.out.println();
    }
}
