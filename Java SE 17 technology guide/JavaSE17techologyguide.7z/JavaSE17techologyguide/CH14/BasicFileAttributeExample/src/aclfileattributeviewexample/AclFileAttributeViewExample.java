package aclfileattributeviewexample;

import fileattributeviewexample.FileAttributeViewExample;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.AclEntry;
import java.nio.file.attribute.AclFileAttributeView;
import java.nio.file.attribute.DosFileAttributes;


public class AclFileAttributeViewExample {
    public static void printAclFileAttributeViewInfo(String pathName1) throws IOException {
        var path1 = Paths.get(pathName1);
        AclFileAttributeViewExample.printAclFileAttributeViewInfo(path1);
    }

    public static void printAclFileAttributeViewInfo(Path path1) throws IOException {
        System.out.printf("All info about dos file attributes of the path1:`%s`.%n",path1.toString());
        AclFileAttributeView view = Files.getFileAttributeView(path1, AclFileAttributeView.class);
        System.out.printf("view:`%s` name is `%s`.%n",view,view.name());

        System.out.printf("The view:`%s` has these AclEntry.%n",view);
        var aclEntries = view.getAcl();
        for(var aclEntry: aclEntries){
            System.out.print(aclEntry.toString().concat("\t"));
        }
        System.out.println();
    }
}
