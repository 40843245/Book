package dosfileattributesexample;

import fileattributeviewexample.FileAttributeViewExample;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.DosFileAttributes;
import java.nio.file.attribute.FileAttributeView;

public class DosFileAttributesExample {
    public static void printDosFileAttributesInfo(String pathName1) throws IOException {
        var path1 = Paths.get(pathName1);
        DosFileAttributesExample.printDosFileAttributesInfo(path1);
    }

    public static void printDosFileAttributesInfo(Path path1) throws IOException {
        System.out.printf("All info about dos file attributes of the path1:`%s`.%n",path1.toString());
        DosFileAttributes attrs = Files.readAttributes(path1, DosFileAttributes.class);
        System.out.printf("Is path1:`%s` archive?`%b`.%n",path1,attrs.isArchive());
        System.out.printf("Is path1:`%s` hidden?`%b`.%n",path1,attrs.isHidden());
        System.out.printf("Is path1:`%s` read only?`%b`.%n",path1,attrs.isReadOnly());
        System.out.printf("Is path1:`%s` in system?`%b`.%n",path1,attrs.isSystem());
    }
}
