package basicfileattributeexample;

import aclfileattributeviewexample.AclFileAttributeViewExample;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

public class BasicFileAttributeExample {
    public static void printBasicFileAttributesInfo(String pathName1) throws IOException {
        var path1 = Paths.get(pathName1);
        AclFileAttributeViewExample.printAclFileAttributeViewInfo(path1);
    }

    public static void printBasicFileAttributesInfo(Path path1) throws IOException {
        System.out.printf("All info about basic attribute of the path1:`%s`.%n",path1.toString());
        BasicFileAttributes attrs = Files.readAttributes(path1, BasicFileAttributes.class);
        System.out.printf("path1.isDirectory?`%b`.%n",attrs.isDirectory());
        System.out.printf("path1.isRegularFile?`%b`.%n",attrs.isRegularFile());
        System.out.printf("path1.isOther?`%b`.%n",attrs.isOther());
        System.out.printf("path1.isSymbolicLink?`%b`.%n",attrs.isSymbolicLink());

        System.out.printf("path1.creationTime:`%s`.%n",attrs.creationTime());
        System.out.printf("path1.lastAccessTime:`%s`.%n",attrs.lastAccessTime());
        System.out.printf("path1.lastModifiedTime:`%s`.%n",attrs.lastModifiedTime());

        System.out.printf("path1.size:`%d`.%n",attrs.size());

        System.out.printf("path1.fileKey:`%s`.%n",attrs.fileKey());
    }
}
