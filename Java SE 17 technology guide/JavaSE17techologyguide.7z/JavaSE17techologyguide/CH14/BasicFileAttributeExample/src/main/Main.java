package main;

import aclfileattributeviewexample.AclFileAttributeViewExample;
import basicfileattributeexample.BasicFileAttributeExample;
import dosfileattributesexample.DosFileAttributesExample;
import fileattributeviewexample.FileAttributeViewExample;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        var pathName1="C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14\\BasicFileAttributeExample\\src\\main\\Main.java";

        System.out.println("----------------------------------");
        BasicFileAttributeExample.printBasicFileAttributesInfo(pathName1);

        System.out.println("----------------------------------");
        FileAttributeViewExample.printFileAttributeViewInfo(pathName1);

        System.out.println("----------------------------------");
        DosFileAttributesExample.printDosFileAttributesInfo(pathName1);

        System.out.println("----------------------------------");
        FileAttributeViewExample.printFileAttributeViewInfo(pathName1);

        System.out.println("----------------------------------");
        AclFileAttributeViewExample.printAclFileAttributeViewInfo(pathName1);
    }
}
