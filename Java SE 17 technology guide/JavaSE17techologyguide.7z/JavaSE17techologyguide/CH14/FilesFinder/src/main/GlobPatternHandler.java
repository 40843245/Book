package main;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

public class GlobPatternHandler {
    public static DirectoryStream<Path> getDirectoryStream(Path startingDir,
                                            String globPattern){
        try{
            var directoryStream = Files.newDirectoryStream(startingDir,globPattern);
            return directoryStream;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static ArrayList<File> findFiles(Path startingDir,
                                            String globPattern){
        ArrayList<File> files = new ArrayList<>();
        var directoryStream1 = GlobPatternHandler.getDirectoryStream(startingDir,globPattern);
        for(var entry: directoryStream1){
            var file = entry.toFile();
            files.add(file);
        }

        var directoryStream2 = GlobPatternHandler.getDirectoryStream(startingDir,"*"+globPattern);
        for(var entry: directoryStream2){
            var file = entry.toFile();
            files.add(file);
        }

        return files;
    }
}
