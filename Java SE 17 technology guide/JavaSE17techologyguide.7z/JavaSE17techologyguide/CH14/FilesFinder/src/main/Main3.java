package main;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class Main3 {
    public static void main(String[] args) {
        var srcDirectory = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH14\\FilesFinder\\src\\main";
        Path startingDir = Paths.get(srcDirectory);
        String glob = "*.java";
        ArrayList<File> files = GlobPatternHandler.findFiles(startingDir,glob);
        files.forEach( file -> {
            System.out.println(file.getName());
        });
    }
}
