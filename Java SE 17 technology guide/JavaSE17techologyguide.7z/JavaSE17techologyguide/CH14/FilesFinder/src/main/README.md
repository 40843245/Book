# Exercise 14-1
## Tip to solve it
> [!TIP]
> Use glob pattern (with exactly one symbol `*` e.g. `*.java`) to search all files that satisfies the glob pattern in direct directory.
> 
> Use glob pattern (with exactly two symbol `*` e.g. `**.java`) to search all files that satisfies the glob pattern in indirect directory.
> 
> For more details about glob pattern, see the section 14.2.5 in this book. 
