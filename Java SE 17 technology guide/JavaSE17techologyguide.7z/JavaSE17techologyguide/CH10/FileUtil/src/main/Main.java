package main;

import fileutil.FileUtil;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        FileUtil.open(args[0],fileInputStream ->{
            var file = new Scanner(fileInputStream);
            while(file.hasNextLine()){
                System.out.println(file.nextLine());
            }
        } );
    }
}
