package fileutil;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.function.UnaryOperator;

public class FileUtil {
    public static void open(String pathName, UnaryOperator<FileInputStream> function){
        FileUtil.open(Paths.get(pathName),function);
    }

    public static void open(Path path, UnaryOperator<FileInputStream> function){
        try(FileInputStream fileInputStream = (FileInputStream) Files.newInputStream(path); ) {
            function.apply(fileInputStream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
