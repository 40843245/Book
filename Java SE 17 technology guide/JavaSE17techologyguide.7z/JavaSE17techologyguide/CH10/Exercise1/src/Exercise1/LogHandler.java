package Exercise1;

import java.io.OutputStream;

public class LogHandler {
    public static String filename = "exception.log";

    public static void write(String data,OutputStream dest){
        dest.write();
    }

    public static void append(){

    }
}
