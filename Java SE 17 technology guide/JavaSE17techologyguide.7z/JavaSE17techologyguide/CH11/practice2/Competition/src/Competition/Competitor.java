package Competition;

import java.util.*;

public class Competitor implements Runnable,Sleepable,CompletionFinish{
    public String name;
    public CompetitorState competitorState;
    int competitionTotalStep;
    Random random;

    public Competitor(String name,CompetitorState competitorState,int competitionTotalStep){
        this.name = name;
        this.competitorState = competitorState;
        this.competitionTotalStep = competitionTotalStep;

        setRandom();
    }

    public void setRandom(){
        this.random = new Random();
        this.random.setSeed(24L);
    }

    @Override
    public void run(){
        this.competitorState.currentStep += this.competitorState.movement;
        printRunningMessage();
    }

    @Override
    public void printRunningMessage(){
        System.out.printf("The competitor %s is running, it moves %d step at present.%n",this.name,this.competitorState.currentStep);
    }

    @Override
    public boolean isFinish(){
        return this.competitorState.currentStep >= this.competitionTotalStep;
    }


    @Override
    public void tryToSleep(){
        if(canSleep()){
            boolean willBeSleep = this.competitorState.sleepFlag[((int)this.random.nextInt()*10)%2];
            if(willBeSleep) {
                sleep();
            }
        }else{
            run();
        }
    }

    @Override
    public void sleep() {
        printSleepMessage();
    }

    @Override
    public boolean canSleep() {
        return this.competitorState.canSleepInCompetition;
    }

    @Override
    public void printSleepMessage() {
        System.out.printf("The competitor %s is sleeping.%n",this.name);
    }
}
