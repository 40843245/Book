package Competition;



public class Competition {
    public Competitor[] competitors;

    public Thread[] threads;

    public Competitor winner;

    public Competition(Competitor[] competitors){
        this.competitors = competitors;
        assignToThreads();
    }

    public Competition(){
        this(new Competitor[]{});
    }

    public void assignToThreads(){
        this.threads = new Thread[this.competitors.length];

        var i = 0;
        for(Competitor competitor: this.competitors){
            this.threads[i] = new Thread(competitor.name);
        }
    }

    public void startThreads(){
        for(Thread thread:this.threads){
            thread.start();
        }
    }

    public void startCompetition(){
        while(true){
            run();
            if(isFinished()){
                break;
            }
        }
        printWinner(this.winner);
    }

    public void startCompetitionInTurn(){
        while(true){
            runInTurn();
            if(isFinished()){
                break;
            }
        }
        printWinner(this.winner);
    }

    public void run(){
        for(Competitor competitor:this.competitors) {
            competitor.run();
        }
    }

    public void runInTurn(){
        var i = 0;
        for(Thread thread: this.threads) {
            interruptAllThreads();
            thread.run();
        }
    }

    private void interruptAllThreads(){
        for(Thread thread: this.threads) {
            thread.interrupt();
        }
    }

    public boolean isFinished(){
        for(Competitor competitor:this.competitors){
            if(competitor.isFinish()){
                this.winner = competitor;
                return true;
            }
        }
        return false;
    }

    public void printWinner(Competitor competitor){
        System.out.printf("The Competitor %s wins.%n",competitor.name);
    }

    public static void main(String[] args){
        Competitor[] competitors = new Competitor[]{
                new Hare(),
                new Tortoise()
        };

        Competition competition ;

        for(var i= 0;i<10;i++){
            competition = new Competition(competitors);
            competition.startCompetition();
        }
    }
}
