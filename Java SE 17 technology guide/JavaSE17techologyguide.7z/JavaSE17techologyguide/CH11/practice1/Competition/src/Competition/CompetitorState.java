package Competition;

import java.util.*;

public class CompetitorState{
    public int movement;
    public int currentStep = 0;
    public boolean canSleepInCompetition = false;

    public boolean[] sleepFlag = {true,false};

    public CompetitorState(boolean canSleepInCompetition,int movement){
        this.canSleepInCompetition = canSleepInCompetition;
        this.movement = movement;
        this.currentStep = 0;
    }

    public CompetitorState(boolean canSleepInCompetition){
        this(canSleepInCompetition,1);
    }

    public CompetitorState(CompetitorState competitorState){
        this.canSleepInCompetition = competitorState.canSleepInCompetition;
        this.movement = competitorState.movement;
        this.currentStep = 0;
    }


}
