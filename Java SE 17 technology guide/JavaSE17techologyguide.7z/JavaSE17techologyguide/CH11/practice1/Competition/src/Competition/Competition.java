package Competition;

public class Competition {
    public Competitor[] competitors;

    public Competitor winner;

    public Competition(Competitor[] competitors){
        this.competitors = competitors;
    }

    public Competition(){
        this.competitors = new Competitor[]{};
    }

    public void startCompetition(){
        while(true){
            run();
            if(isFinished()){
                break;
            }
        }
        printWinner(this.winner);
    }

    public void run(){
        for(Competitor competitor:this.competitors) {
            competitor.run();
        }
    }

    public boolean isFinished(){
        for(Competitor competitor:this.competitors){
            if(competitor.isFinish()){
                this.winner = competitor;
                return true;
            }
        }
        return false;
    }

    public void printWinner(Competitor competitor){
        System.out.printf("The Competitor %s wins.%n",competitor.name);
    }

    public static void main(String[] args){
        Competitor[] competitors = new Competitor[]{
                new Hare(),
                new Tortoise()
        };
        Competition competition = new Competition(competitors);
        competition.startCompetition();
    }
}
