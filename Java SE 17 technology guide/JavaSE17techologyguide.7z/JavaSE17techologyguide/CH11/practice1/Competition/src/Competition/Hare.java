package Competition;

public class Hare extends Competitor{
    public Hare(){
        super("hare",new CompetitorState(true,2),10);
    }
}