package Competition;

public interface Runnable {
    abstract void run();
    abstract void printRunningMessage();
}
