package Competition;

public class Tortoise extends Competitor{

    public Tortoise(){
        super("tortoise",new CompetitorState(true,2),10);
    }
}
