package Competition;

public interface CompletionFinish {
    abstract boolean isFinish();
}
