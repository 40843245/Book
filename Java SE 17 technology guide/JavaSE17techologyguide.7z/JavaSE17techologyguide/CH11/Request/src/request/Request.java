package request;

public interface Request {
    void execute();
}
