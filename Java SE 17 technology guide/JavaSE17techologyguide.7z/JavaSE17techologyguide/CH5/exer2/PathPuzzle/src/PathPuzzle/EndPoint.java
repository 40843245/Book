package PathPuzzle;

public class EndPoint {
    Position position;

    public EndPoint(Position position){
        this.position = position;
    }

    public EndPoint(int x,int y){
        this(new Position(x,y));
    }

    public EndPoint(){
        this(new Position());
    }
}
