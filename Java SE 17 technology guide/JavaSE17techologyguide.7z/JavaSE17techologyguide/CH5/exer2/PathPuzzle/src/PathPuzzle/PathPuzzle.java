package PathPuzzle;

public class PathPuzzle {
    Mouse mouse;
    EndPoint endPoint;
    Maze maze;

    public PathPuzzle(Mouse mouse,Maze maze){
        this.mouse = mouse;
        this.maze = maze;
    }

    public PathPuzzle(){
        this(new Mouse(0,1),new Maze());
    }

    public void findPath() {
        int isGameOver = 0;
        while(isGameOver == 0){
            isGameOver = move();
        }
        endGame(isGameOver);
    }
    public int move(){
        if(reachEndPoint()){
            return 1;
        }

        Position leftPoint = this.mouse.position.add(new Position(-1,0));
        Position rightPoint = this.mouse.position.add(new Position(1,0));
        Position upPoint = this.mouse.position.add(new Position(0,-1));
        Position downPoint = this.mouse.position.add(new Position(0,1));

        Position[] points = new Position[]{
          leftPoint,
          rightPoint,
          upPoint,
          downPoint
        };

        boolean walkFlag = false;

        for(Position point: points){
            if(tryToWalkTo(point)){
                return -1;
            }
        }
        return 0;
    }

    private boolean tryToWalkTo(Position newPosition){
        if(canWalkTo(newPosition)){
            walkTo(newPosition);
            return true;
        }
        return false;
    }

    private boolean canWalkTo(Position newPosition){
        return this.maze.map[newPosition.x][newPosition.y] == 0;
    }

    private void walkTo(Position newPosition){
        this.mouse.position = newPosition;
        updateMaze(newPosition);
    }

    private void updateMaze(Position newPosition){
        this.maze.map[newPosition.x][newPosition.y] = 1;
    }

    private boolean reachEndPoint(){
        return mouse.position == endPoint.position;
    }

    private void endGame(int isGameOver){
        if(isGameOver==1){
            printSuccessMessage();
        }else{
            printFailureMessage();
        }
    }

    private void printSuccessMessage(){
        System.out.println("Congrulations!!!");
    }

    private void printFailureMessage(){
        System.out.println("Failure!!!");
    }

    public static void main(String args){
        PathPuzzle pathPuzzle = new PathPuzzle();
        pathPuzzle.findPath();
    }
}
