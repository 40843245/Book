package PathPuzzle;

public class Position {
    int x;
    int y;

    public Position(int x,int y){
        this.x = x;
        this.y = y;
    }

    public Position(){
        this(0,0);
    }

    @Override
    public boolean equals(Object other){
        if(this==other){
            return true;
        }

        if(!(other instanceof Position)){
            return false;
        }

        Position newPosition = (Position)other;
        return this.x == newPosition.x && this.y == newPosition.y;
    }

    public Position add(Position other){
        return new Position(this.x +other.x,this.y+other.y);
    }

    public Position subtract(Position other){
        return new Position(this.x - other.x,this.y - other.y);
    }
}
