package PathPuzzle;

public class Maze {
    public int[][] map;

    public Maze(int map[][]){
        this.map = map;
    }

    public Maze(){
        this(new int[][]{
                {2,2,2,2,2,2,2},
                {0,0,0,0,0,0,2},
                {2,0,2,0,2,0,2},
                {2,2,0,2,0,2,2},
                {2,0,0,2,0,0,2},
                {2,2,2,2,2,0,2}
        });
    }
}
