package PathPuzzle;

public class Mouse {
    Position position;

    public Mouse(Position position){
        this.position = position;
    }

    public Mouse(int x,int y){
        this(new Position(x,y));
    }

    public Mouse(){
        this(new Position());
    }
}
