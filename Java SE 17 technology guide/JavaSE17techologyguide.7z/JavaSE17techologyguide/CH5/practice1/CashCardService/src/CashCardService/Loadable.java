package CashCardService;

public interface Loadable {
    CashCard load(String cardId);
}
