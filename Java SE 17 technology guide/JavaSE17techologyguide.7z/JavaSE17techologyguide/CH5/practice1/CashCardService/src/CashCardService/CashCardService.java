package CashCardService;

import java.util.*;

public class CashCardService implements Loadable,Savable,Chargable{
    private ArrayList<CashCard> cashCards;

    public CashCardService(ArrayList<CashCard> cashCards){
        this.cashCards = cashCards;
    }

    @Override
    public CashCard load(String cardId){
        CashCard cashCard = this.findFirst(cardId);
        if(cashCard == null){
            throw new IllegalArgumentException(String.format("Failed to load. Can not find cardId:%s among these cash cards.%n", cardId));
        }
        return cashCard;
    }

    public boolean contain(String cardId){
        int size = this.cashCards.size();
        for (CashCard cashCard : this.cashCards) {
            if (cashCard.cardId.equals(cardId)) {
                return true;
            }
        }
        return false;
    }

    public boolean contain(CashCard cashCard){
        int size = this.cashCards.size();
        for (CashCard cashCard1 : this.cashCards) {
            if (cashCard1.equals(cashCard)) {
                return true;
            }
        }
        return false;
    }

    public CashCard findFirst(String cardId){
        int size = this.cashCards.size();
        for (CashCard cashCard : this.cashCards) {
            if (cashCard.cardId.equals(cardId)) {
                return cashCard;
            }
        }
        return null;
    }

    @Override
    public void save(CashCard cashCard){
        if(!this.cashCards.contains(cashCard)){
            this.cashCards.add(cashCard);
        }
    }

    @Override
    public void store(CashCard cashCard,int number){
        if(number<0){
            throw new IllegalArgumentException(String.format("Can Not store a negative number: %d.",number));
        }

        assert number>=0: String.format("Can Not store a negative number: %d.",number) ;

        if(!contain(cashCard)){
            throw new IllegalArgumentException(String.format("The cash card %s does NOT exist in current database.%n",cashCard.toString()));
        }

        assert contain(cashCard): String.format("The cash card %s does NOT exist in current database.%n",cashCard.toString());
    }

    @Override
    public void charge(CashCard cashCard,int number){
        if(number<0){
            throw new IllegalArgumentException(String.format("Can Not charge a negative number: %d.",number));
        }

        assert number>=0: String.format("Can Not charge a negative number: %d.",number) ;

        if(!contain(cashCard)){
            throw new IllegalArgumentException(String.format("The cash card %s does NOT exist in current database.%n",cashCard.toString()));
        }

        assert contain(cashCard): String.format("The cash card %s does NOT exist in current database.%n",cashCard.toString());
    }

    public static void main(String[] args) {
        ArrayList<CashCard> cashCards = new ArrayList<CashCard>();

        cashCards.add(new CashCard("1", 1000, 0));
        cashCards.add(new CashCard("2", 2000, 0));
        cashCards.add(new CashCard("3", 3000, 0));
        cashCards.add(new CashCard("4", 4000, 0));
        cashCards.add(new CashCard("5", 5000, 0));

        CashCardService cashCardService = new CashCardService(cashCards);
    }
}