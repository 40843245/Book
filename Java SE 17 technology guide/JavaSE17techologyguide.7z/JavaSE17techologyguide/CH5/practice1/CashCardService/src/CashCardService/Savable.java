package CashCardService;

public interface Savable {
    abstract void save(CashCard cashCard);
}
