package CashCardService;

public interface Chargable {
    abstract void store(CashCard cashCard,int number);
    abstract void charge(CashCard cashCard,int number);
}
