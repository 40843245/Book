package parallelprefix;

public class Main {
    public static void main(String[] args){
        var array = new int[]{5,3,2,4,1};
        var parallelPrefix = new ParallelPrefix(array);

        System.out.println("--------------------------------------------");
        parallelPrefix.printArray();
        parallelPrefix.printInitArray();

        parallelPrefix.acculumateArrayInParallel();

        System.out.println("--------------------------------------------");
        parallelPrefix.printArray();
        parallelPrefix.printInitArray();

        parallelPrefix.setAllElementsInParallel(-1);

        System.out.println("--------------------------------------------");
        parallelPrefix.printArray();
        parallelPrefix.printArray();

        parallelPrefix.sortInParallel();

        System.out.println("--------------------------------------------");
        parallelPrefix.printArray();
        parallelPrefix.printInitArray();
    }
}
