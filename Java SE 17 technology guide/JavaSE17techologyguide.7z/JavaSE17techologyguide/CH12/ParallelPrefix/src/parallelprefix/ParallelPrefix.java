package parallelprefix;

import java.util.Arrays;

public class ParallelPrefix {
    private int[] array;
    private int[] initArray;

    public ParallelPrefix(int[] array){
        this.array = array;
        this.initArray = this.array.clone();
    }

    private void backup(){
        this.array = this.initArray.clone();
    }

    public void printArray(){
        System.out.println("this.array:");
        System.out.println(Arrays.toString(this.array));
    }

    public void printInitArray(){
        System.out.println("this.initArray:");
        System.out.println(Arrays.toString(this.initArray));
    }

    public void acculumateArrayInParallel(){
        backup();
        Arrays.parallelPrefix(this.array,(left,right)->left+right);
    }

    public void setAllElementsInParallel(int number){
        backup();
        Arrays.parallelSetAll(this.array, index -> number );
    }

    public void sortInParallel(){
        backup();
        Arrays.parallelSort(this.array);
    }
}
