package string;

import java.util.concurrent.ExecutorService;

public class MyString {
    public static String toUpperCase(String s1, ExecutorService poolService){
        return s1.toUpperCase();
    }
}
