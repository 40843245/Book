package completablefuture;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

public class CompletableFutureApplication1 {
    public static CompletableFuture<String> readFileAsync(String fileName, ExecutorService executorService){
        var result = CompletableFuture.supplyAsync(()->{
                try{
                    return new String(Files.readAllBytes(Paths.get(fileName)));
                } catch (IOException ex) {
                    throw new UncheckedIOException(ex);
                }
        },executorService);
        return result;
    }
}
