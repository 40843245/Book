package completablefuture;

import string.MyString;

import java.util.Optional;
import java.util.concurrent.Executors;

public class Main3 {
    public static void main(String[] args){
        var fileName ="C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH12\\CompletableFuture\\src\\testdata\\input\\data1.txt";

        var poolService = Executors.newFixedThreadPool(10);

        CompletableFutureApplication1.readFileAsync(fileName,poolService)
                //.thenCompose(content -> MyString.toUpperCase(content,poolService))
                .whenComplete((ok,ex)->{
                    Optional.ofNullable(ex)
                            .ifPresentOrElse(
                                    Throwable::printStackTrace,
                                    ()->System.out.println(ok)
                            );
                }).join();

        poolService.shutdown();
    }
}
