package aggregatefunctions;

import java.util.List;

public class AggregateFunctions {
    public static int sum(List<Member> members){
        var sum = members.stream().filter(member -> member.gender == Gender.FEMALE).mapToInt(Member::getAge).sum();
        return sum;
    }

    public static double average(List<Member> members){
        var average = members.stream().filter(member -> member.gender == Gender.FEMALE).mapToInt(Member::getAge).average().getAsDouble();
        return average;
    }

    public static int max(List<Member> members){
        var max = members.stream().filter(member -> member.gender == Gender.FEMALE).mapToInt(Member::getAge).max().getAsInt();
        return max;
    }

    public static int min(List<Member> members){
        var min = members.stream().filter(member -> member.gender == Gender.FEMALE).mapToInt(Member::getAge).min().getAsInt();
        return min;
    }
}
