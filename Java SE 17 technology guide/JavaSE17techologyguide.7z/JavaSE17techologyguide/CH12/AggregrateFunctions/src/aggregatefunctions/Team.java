package aggregatefunctions;

import java.util.List;

public class Team {
    public String name;
    public String teamType;
    public List<Member> members;

    public Team(String name,String teamType,List<Member> members){
        this.name = name;
        this.teamType = teamType;
        this.members = members;
    }

    public Team(){
        this("μ's","dance", List.of(
                      new Member("Kosaka Honoka",Gender.FEMALE,20),//高坂穗乃果
                      new Member("Ayase Eli",Gender.FEMALE,22),//絢瀨繪里
                      new Member("Minami Kotori",Gender.FEMALE,20),//南琴梨／南小鳥
                      new Member("Sonoda Umi",Gender.FEMALE,20),//園田海未
                      new Member("Hoshizora Rin",Gender.FEMALE,20),//星空凛
                      new Member("Nishikino Maki",Gender.FEMALE,21),//西木野真姬
                      new Member("Tojo Nozomi",Gender.FEMALE,22),//東條希
                      new Member("Koizumi Hanayo",Gender.FEMALE,20),//小泉花陽
                      new Member("Yazawa Nico",Gender.FEMALE,21)//矢澤日香／矢澤妮可／矢澤妮歌／矢澤仁子
                )
        );
    }
}


