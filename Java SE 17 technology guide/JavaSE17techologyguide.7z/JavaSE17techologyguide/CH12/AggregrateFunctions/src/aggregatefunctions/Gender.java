package aggregatefunctions;

public enum Gender {
    MALE,
    FEMALE
}
