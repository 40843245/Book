package aggregatefunctions;

public class Member {
    public String name;
    public Gender gender;
    public int age;

    public Member(String name,Gender gender,int age){
        this.name = name;
        this.gender = gender;
        this.age = age;
    }

    public int getAge(){
        return this.age;
    }
}
