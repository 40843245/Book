package comparabledefinition;

public interface Comparable<T> {
    int compareTo(T that);

    default boolean equalTo(T that){
        return compareTo(that) == 0;
    }

    default boolean notEqualTo(T that){
        return compareTo(that) != 0;
    }

    default boolean lessThan(T that){
        return compareTo(that) < 0;
    }

    default boolean lessThanOrEqualTo(T that){
        return compareTo(that) <= 0;
    }

    default boolean greaterThan(T that){
        return compareTo(that) > 0;
    }

    default boolean greaterThanOrEqualTo(T that){
        return compareTo(that) >= 0;
    }
}