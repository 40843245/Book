package defaultmethods;

import java.util.*;

public class StandardDeck implements Deck{

    private ArrayList<Card> entireDeck;
    private ArrayList<Deck> decks;

    @Override
    public ArrayList<Card> getCards() {
        return this.entireDeck;
    }

    @Override
    public Deck deckFactory() {
        return null;
    }

    @Override
    public int size() {
        return this.entireDeck.size();
    }

    @Override
    public void addCard(Card card) {
        this.entireDeck.add(card);
    }

    @Override
    public void addCards(List<Card> cards) {
        this.entireDeck.addAll(cards);
    }

    @Override
    public void addDeck(Deck deck) {
        this.decks.add(deck);
    }

    @Override
    public void shuffle() {
        Collections.shuffle(this.entireDeck);
    }

    @Override
    public void sort() {
        Collections.sort(entireDeck);
    }

    @Override
    public void sort(Comparator<Card> c) {
        Collections.sort(entireDeck,c);
    }

    @Override
    public String deckToString() {
        String text = "";
        for(var deck : this.entireDeck) {
            text = text.concat(deck.toString());
        }
        return text;
    }

    @Override
    public Map<Integer, Deck> deal(int players, int numberOfCards) throws IllegalArgumentException {
        return Map.of();
    }

    public StandardDeck(ArrayList<Card> entireDeck,ArrayList<Deck> decks){
        this.entireDeck = entireDeck;
        this.decks = decks;
    }

    public StandardDeck(ArrayList<Card> entireDeck){
        this(entireDeck,null);
    }

    public StandardDeck(){
        this(new ArrayList<Card>(),null);
    }

    @Override
    public String toString(){
        if(this.entireDeck.isEmpty()){
            return "There are no cards.\n";
        }

        var text = "";
        for(var card : this.entireDeck){
            text = text.concat(String.valueOf(card.getRank().value()));
            text = text.concat("\t");
        }
        text = text.concat("\n");
        return text;
    }
}
