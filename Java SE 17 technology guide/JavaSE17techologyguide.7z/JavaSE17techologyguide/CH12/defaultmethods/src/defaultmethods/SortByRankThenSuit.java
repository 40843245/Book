package defaultmethods;

import java.util.Comparator;
import java.util.function.Function;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;
import java.util.function.ToLongFunction;

public class SortByRankThenSuit implements Comparator<Card> {
    @Override
    public int compare(Card card1, Card card2) {
        int compVal = card1.getRank().value() - card2.getRank().value();
        if (compVal != 0)
            return compVal;
        return card1.getSuit().value() - card2.getSuit().value();
    }

    @Override
    public Comparator<Card> reversed() {
        return Comparator.super.reversed();
    }

    @Override
    public Comparator<Card> thenComparing(Comparator<? super Card> other) {
        return Comparator.super.thenComparing(other);
    }

    @Override
    public <U> Comparator<Card> thenComparing(Function<? super Card, ? extends U> keyExtractor, Comparator<? super U> keyComparator) {
        return Comparator.super.thenComparing(keyExtractor, keyComparator);
    }

    @Override
    public <U extends Comparable<? super U>> Comparator<Card> thenComparing(Function<? super Card, ? extends U> keyExtractor) {
        return Comparator.super.thenComparing(keyExtractor);
    }

    @Override
    public Comparator<Card> thenComparingInt(ToIntFunction<? super Card> keyExtractor) {
        return Comparator.super.thenComparingInt(keyExtractor);
    }

    @Override
    public Comparator<Card> thenComparingLong(ToLongFunction<? super Card> keyExtractor) {
        return Comparator.super.thenComparingLong(keyExtractor);
    }

    @Override
    public Comparator<Card> thenComparingDouble(ToDoubleFunction<? super Card> keyExtractor) {
        return Comparator.super.thenComparingDouble(keyExtractor);
    }
}
