package defaultmethods;

public class PlayingCard implements Card{
    private Card.Suit suit;
    private Card.Rank rank;

    @Override
    public int compareTo(Card card) {
        return this.hashCode() - card.hashCode();
    }

    @Override
    public Suit getSuit() {
        return this.suit;
    }

    @Override
    public Rank getRank() {
        return this.rank;
    }

    public int hashCode() {
        return ((this.suit.value()-1)*13)+this.rank.value();
    }

    public PlayingCard(Card.Suit suit, Card.Rank rank){
        this.suit = suit;
        this.rank = rank;
    }
}
