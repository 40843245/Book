package defaultmethods;

public class Main {
    public static void main(String[] args){
        StandardDeck myDeck = new StandardDeck();
        System.out.println(myDeck);
        myDeck.shuffle();
        System.out.println(myDeck);
        myDeck.sort(new SortByRankThenSuit());
        System.out.println(myDeck);
    }
}
