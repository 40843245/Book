package optional;

import java.util.Map;
import java.util.Optional;

public class Main {
    private static String findLastName1(Map<String,String> names, String firstName){
        var found = Optional.ofNullable(names.get(firstName));
        if(found.isPresent()){
            return found.get();
        }
        return "NOT found.";
    }

    private static String findLastName2(Map<String,String> names, String firstName){
        var found = Optional.ofNullable(names.get(firstName));
        return found.orElse("NOT found.");
    }

    private static void printName(String firstName,String lastName){
        if(lastName.equals("NOT found.")){
            System.out.println(lastName);
        }else {
            System.out.printf("%s %s is one of members in μ's team in LoveLive school idol project.%n",firstName,lastName);
        }
    }

    public static void main(String[] args){
        // names of all role in μ's team in LoveLive school idol project (LoveLive) (a Japanese Animation)
        Map<String,String> μsrolesName = Map.of(
            "Kosaka" ,"Honoka",//高坂穗乃果
                "Ayase","Eli",//絢瀨繪里
                "Minami","Kotori",//南琴梨／南小鳥
                "Sonoda" ,"Umi",//園田海未
                "Hoshizora","Rin",//星空凛
                "Nishikino","Maki",//西木野真姬
                "Tojo","Nozomi", //東條希
                "Koizumi","Hanayo", //小泉花陽
                "Yazawa","Nico"//矢澤日香／矢澤妮可／矢澤妮歌／矢澤仁子
        );
        String firstName = "";
        String lastName = "";

        System.out.println("------------------------------");

        firstName = "Tojo";
        lastName = Main.findLastName1(μsrolesName,firstName);
        Main.printName(firstName,lastName);

        firstName = "Kosaka";
        lastName = Main.findLastName1(μsrolesName,firstName);
        Main.printName(firstName,lastName);

        firstName = "Akari";
        lastName = Main.findLastName1(μsrolesName,firstName);
        Main.printName(firstName,lastName);

        System.out.println("------------------------------");

        firstName = "Tojo";
        lastName = Main.findLastName2(μsrolesName,firstName);
        Main.printName(firstName,lastName);

        firstName = "Kosaka";
        lastName = Main.findLastName2(μsrolesName,firstName);
        Main.printName(firstName,lastName);

        firstName = "Akari";
        lastName = Main.findLastName2(μsrolesName,firstName);
        Main.printName(firstName,lastName);



    }
}
