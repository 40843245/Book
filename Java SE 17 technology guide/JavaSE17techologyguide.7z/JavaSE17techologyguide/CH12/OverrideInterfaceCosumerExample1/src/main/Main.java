package main;

import consumerimpl.ConsumerImpl;

import java.util.function.Consumer;

public class Main {
    public static void main(String[] args){
        var consumer = new Consumer<String>(){
            @Override
            public void accept(String s) {
                System.out.println("The accept method in Consumer interface is implemented in Main.java file.");
            }

            @Override
            public Consumer<String> andThen(Consumer<? super String> after) {
                System.out.println("The andThen method in Consumer interface is implemented in Main.java file.");
                if(after.equals(null)){
                    System.out.println("The after argument in Consumer method equals to null.");
                    return null;
                }
                return Consumer.super.andThen(after);
            }
        };
        var consumerImpl = new ConsumerImpl(consumer);
        consumerImpl.forEach(consumer);
    }
}
