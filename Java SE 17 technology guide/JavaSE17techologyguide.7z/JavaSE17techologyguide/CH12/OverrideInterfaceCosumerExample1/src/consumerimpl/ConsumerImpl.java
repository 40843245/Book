package consumerimpl;

import java.util.Iterator;
import java.util.Spliterator;
import java.util.function.Consumer;

public class ConsumerImpl<T> implements Iterable{

    private Consumer consumer = null;

    @Override
    public Iterator iterator() {
        return null;
    }

    @Override
    public void forEach(Consumer action) {
        System.out.println("The forEach method in Iterable interface is implemented.");
        Iterable.super.forEach(action);
    }

    @Override
    public Spliterator spliterator() {
        return Iterable.super.spliterator();
    }

    public ConsumerImpl(Consumer consumer){
        this.consumer = consumer;
    }
}
