package LineStartsWith;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class LineStartsWith {
    private static String getFirstLine(String fileName,String prefix) throws IOException {
        var lines = Files.lines(Paths.get(fileName));
        var maybeMatched = lines.filter(line->line.startsWith(prefix)).findFirst();
        return maybeMatched.orElse("No matched line");
    }

    public static void main(String[] args) throws IOException {
        var fileName = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH12\\LineStartsWith\\src\\LineStartsWith\\testdata\\input\\data1.txt";
        var prefix = new String("Hello");
        var maybeMatched = LineStartsWith.getFirstLine(fileName,prefix);
        System.out.println(maybeMatched);
    }
}
