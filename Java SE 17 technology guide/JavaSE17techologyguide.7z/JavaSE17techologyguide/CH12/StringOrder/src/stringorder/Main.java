package stringorder;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args){
        // names of all role in μ's team in LoveLive school idol project (LoveLive) (a Japanese Animation)
        ArrayList<String> μsrolesName = new ArrayList<String>();
        μsrolesName.add("Kosaka Honoka");//高坂穗乃果
        μsrolesName.add("Ayase Eli");//絢瀨繪里
        μsrolesName.add("Minami Kotori");//南琴梨／南小鳥
        μsrolesName.add("Sonoda Umi");//園田海未
        μsrolesName.add("Hoshizora Rin");//星空凛
        μsrolesName.add("Nishikino Maki");//西木野真姬
        μsrolesName.add("Tojo Nozomi"); //東條希
        μsrolesName.add("Koizumi Hanayo");//小泉花陽
        μsrolesName.add("Yazawa Nico");//矢澤日香／矢澤妮可／矢澤妮歌／矢澤仁子

        System.out.println("---------------------------------------");
        for(var μsroleName: μsrolesName){
            System.out.println(μsroleName);
        }

        μsrolesName.sort(StringOrder::byLength);

        System.out.println("---------------------------------------");
        for(var μsroleName: μsrolesName){
            System.out.println(μsroleName);
        }

        μsrolesName.sort((name1,name2)-> name1.length() - name2.length());

        System.out.println("---------------------------------------");
        for(var μsroleName: μsrolesName){
            System.out.println(μsroleName);
        }
    }
}
