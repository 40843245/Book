# reference
[LoveLive角色列表](https://zh.wikipedia.org/wiki/Love_Live!%E4%BA%BA%E7%89%A9%E5%88%97%E8%A1%A8)