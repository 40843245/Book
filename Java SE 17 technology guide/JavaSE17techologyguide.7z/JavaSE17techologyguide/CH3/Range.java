package CH3;

public class Range{
	public static void main(String[] args){
		System.out.printf("The min of byte:%d, the max of byte:%d.%n", Byte.MIN_VALUE,Byte.MAX_VALUE);
		System.out.printf("The min of short:%d, the max of short:%d.%n", Short.MIN_VALUE,Short.MAX_VALUE);
		System.out.printf("The min of int:%d, the max of int:%d.%n", Integer.MIN_VALUE,Integer.MAX_VALUE);
		System.out.printf("The min of long:%d, the max of long:%d.%n", Long.MIN_VALUE,Long.MAX_VALUE);
		System.out.printf("The min of char:%h, the max of char:%h.%n", Character.MIN_VALUE,Character.MAX_VALUE);
		System.out.printf("The true value in boolean:%b, The false value in boolean:%b.%n", Boolean.TRUE,Boolean.FALSE);
	}
  }