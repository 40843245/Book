package NumberHandler;

import java.util.ArrayList;

public class FibonacciHandler {
    public static ArrayList<Integer> fibonacciArray = new ArrayList<Integer>();
    public static void build(int n){
        NumberHandler.FibonacciHandler.fibonacciArray.add(0);
        NumberHandler.FibonacciHandler.fibonacciArray.add(1);
        for(var i=2;i<=2000;i++){
            var t = NumberHandler.FibonacciHandler.fibonacciArray.get(n-1)+NumberHandler.FibonacciHandler.fibonacciArray.get(n-2);
            NumberHandler.FibonacciHandler.fibonacciArray.add(t);
        }
    }

    public static void reset(){
        NumberHandler.FibonacciHandler.fibonacciArray.clear();
    }
}
