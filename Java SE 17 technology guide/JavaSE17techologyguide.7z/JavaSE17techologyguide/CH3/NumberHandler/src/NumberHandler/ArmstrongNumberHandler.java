package NumberHandler;

import java.util.ArrayList;

public class ArmstrongNumberHandler {
    public static boolean isArmStrongNumber(int m){
        ArrayList<Integer> digits = DigitHandler.getDigits(m);
        var total = 0;
        var length = digits.size();
        for(var i=0;i<length;i++){
            var digit = digits.get(i);
            total += Math.pow(digit, length);
        }
        return total == m;
    }
}
