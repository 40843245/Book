package NumberHandler;

import java.util.ArrayList;

public class FactorHandler {
    public static int getMaxFactor(int m, int n){
        ArrayList<Integer> factorsOfM = FactorHandler.getFactors(m);
        ArrayList<Integer> factorsOfN = FactorHandler.getFactors(n);
        ArrayList<Integer> commonFactors = ArrayListHandler.getCommonElements(factorsOfM, factorsOfN);
        int maxFactor = ArrayListHandler.max(commonFactors);
        return maxFactor;
    }
    public static ArrayList<Integer> getFactors(int m){
        ArrayList<Integer> factors = new ArrayList<Integer>();

        factors.add(1);
        for(var i=2;i<Math.sqrt(m);i++){
            if(m % i == 0 ){
                factors.add(i);
            }
        }
        return factors;
    }
}
