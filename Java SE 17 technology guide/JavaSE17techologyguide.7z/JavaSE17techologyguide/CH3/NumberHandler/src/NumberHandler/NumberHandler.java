package NumberHandler;

public class NumberHandler{
    public static void main(String[] args){
        // # CH2 ex1
        var m = 1000;
        var n = 495;

        System.out.printf("max factor of %d and %d is %d.%n",m,n,FactorHandler.getMaxFactor(m,n));

        // # CH2 ex2
        for(var i=100;i<1000;i++){
            System.out.printf("i:%d is an armstrong number? %b.%n",i,ArmstrongNumberHandler.isArmStrongNumber(i));
        }

        // # CH4 ex1
        n = 10;
        for(var i =0 ; i<n;i++){
            var t = FibonacciHandler.fibonacciArray.get(i);
            System.out.printf("%d ",t);
        }
    }
}
