package NumberHandler;

import java.util.ArrayList;

public class ArrayListHandler {
    public static <T> ArrayList<T> getCommonElements(ArrayList<T> arrayList1, ArrayList<T> arrayList2){
        ArrayList<T> commonArrayList = new ArrayList<T>();

        int minLength = Math.min(arrayList1.size(), arrayList2.size());
        for(var i=0;i<minLength;i++){
            var arrayList1Elem = arrayList1.get(i);
            var arrayList2Elem = arrayList2.get(i);
            if(arrayList1Elem.equals(arrayList2Elem)){
                commonArrayList.add(arrayList1Elem);
            }
        }
        return commonArrayList;
    }

    public static int max(ArrayList<Integer> arrayList){
        var length = arrayList.size();
        var maxValue = Integer.MIN_VALUE;
        for(var i =0;i<length;i++){
            maxValue = Math.max(arrayList.get(i),maxValue);
        }
        return maxValue;
    }
}
