package NumberHandler;

import java.util.ArrayList;
import java.util.Collections;

public class DigitHandler {
    public static ArrayList<Integer> getDigits(int m){
        ArrayList<Integer> digits = new ArrayList<Integer>();
        var num = m;
        while(num > 1){
            digits.add(num%10);
            num /= 10;
        }
        Collections.reverse(digits);
        return digits;
    }
}
