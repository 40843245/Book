package Exercise1.jdbcupdateutil;


import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JDBCUpdateUtil {

    public DataSource dataSource;
    public String sqlCommand;

    public JDBCUpdateUtil(DataSource dataSource, String sqlCommand){
        this.dataSource = dataSource;
        this.sqlCommand = sqlCommand;
    }

    public void update(){
        try(Connection connection = dataSource.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(this.sqlCommand);
            ){
                preparedStatement.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
