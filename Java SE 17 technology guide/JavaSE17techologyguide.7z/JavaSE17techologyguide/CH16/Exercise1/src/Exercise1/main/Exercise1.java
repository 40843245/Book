package Exercise1.main;

import Exercise1.databaseconnectioninfo.DatabaseConnectionInfo;
import Exercise1.datasoureutil.DataSourceUtil;
import Exercise1.jdbcupdateutil.JDBCUpdateUtil;

import java.io.IOException;

public class Exercise1 {
    public static void main(String[] args) throws IOException {
        var sqlCommand = """
                CREATE TABLE messages(
                    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(20) NOT NULL,
                    email VARCHAR(40),
                    msg VARCHAR(256) NOT NULL
                );
                """;

        var JDBCUpdateUtilInst = new JDBCUpdateUtil(new DataSourceUtil(),
                sqlCommand
        );

        JDBCUpdateUtilInst.update();

    }
}
