package Exercise1.datasoureutil;

import javax.sql.DataSource;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

public class DataSourceUtil implements DataSource {

    private final Properties properties;
    private final String url;
    private final int maxConnection;
    private List<Connection> connections;

    public DataSourceUtil() throws IOException {
        this("jdbc.properties");
    }

    public DataSourceUtil(String configFile) throws IOException {
        this.properties = new Properties();
        this.properties.load(new FileInputStream(configFile));
        this.url = this.properties.getProperty("cc.openhome.url");
        this.maxConnection = Integer.parseInt(this.properties.getProperty("cc.openhome.poolmax"));
        this.connections = Collections.synchronizedList(new ArrayList<>());
    }

    @Override
    public synchronized Connection getConnection() throws SQLException {
        if(this.connections.isEmpty()){
            return new ConnectionWrapper(DriverManager.getConnection(this.url),
                    this.connections,
                    this.maxConnection);
        }

        return this.connections.remove(this.connections.size()-1);
    }

    @Override
    public synchronized Connection getConnection(String s, String s1) throws SQLException {
        return this.getConnection();
    }

    @Override
    public PrintWriter getLogWriter() throws SQLException {
        return null;
    }

    @Override
    public void setLogWriter(PrintWriter printWriter) throws SQLException {

    }

    @Override
    public void setLoginTimeout(int i) throws SQLException {
    }

    @Override
    public int getLoginTimeout() throws SQLException {
        return 0;
    }

    @Override
    public Logger getParentLogger() throws SQLFeatureNotSupportedException {
        return null;
    }

    @Override
    public ShardingKeyBuilder createShardingKeyBuilder() throws SQLException {
        return DataSource.super.createShardingKeyBuilder();
    }

    @Override
    public ConnectionBuilder createConnectionBuilder() throws SQLException {
        return DataSource.super.createConnectionBuilder();
    }

    @Override
    public <T> T unwrap(Class<T> aClass) throws SQLException {
        return null;
    }

    @Override
    public boolean isWrapperFor(Class<?> aClass) throws SQLException {
        return false;
    }
}
