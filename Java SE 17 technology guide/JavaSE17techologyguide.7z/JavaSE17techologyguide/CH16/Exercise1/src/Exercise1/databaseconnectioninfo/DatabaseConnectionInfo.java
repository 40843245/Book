package Exercise1.databaseconnectioninfo;

public class DatabaseConnectionInfo {
    public static final String URL = "jdbc:mysql://localhost:3306/company";
    public static final String USER = "root";
    public static final String PASSWORD = "MySQLJay30";
}
