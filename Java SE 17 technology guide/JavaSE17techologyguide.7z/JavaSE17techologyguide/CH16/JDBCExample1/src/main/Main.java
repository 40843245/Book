package main;

import drivermanager.databaseconnectioninfo.DatabaseConnectionInfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
    public static void main(String[] args){
        try(Connection connection= DriverManager.getConnection(
                DatabaseConnectionInfo.URL,
                DatabaseConnectionInfo.USER,
                DatabaseConnectionInfo.PASSWORD);
            Statement statement = connection.createStatement();
        ) {
            connection.setAutoCommit(false);
            statement.executeUpdate("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (1,\"JACK\",20);");
            var point = connection.setSavepoint();
            statement.executeUpdate("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (2,\"Eli\",21);");
            statement.executeUpdate("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (3,\"Midori\",22);");
            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
