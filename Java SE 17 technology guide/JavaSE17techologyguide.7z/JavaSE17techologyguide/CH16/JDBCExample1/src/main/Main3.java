package main;

import drivermanager.databaseconnectioninfo.DatabaseConnectionInfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import static java.sql.Connection.*;

public class Main3 {
    public static void main(String[] args){
        try(Connection connection= DriverManager.getConnection(
                DatabaseConnectionInfo.URL,
                DatabaseConnectionInfo.USER,
                DatabaseConnectionInfo.PASSWORD);
            Statement statement = connection.createStatement();
        ) {
            connection.setAutoCommit(false);

            connection.setTransactionIsolation(Connection.TRANSACTION_NONE); // avoid nothing
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (1,\"JACK\",20);");
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (2,\"Eli\",21);");
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (3,\"Midori\",22);");
            statement.executeBatch();

            connection.commit();
            connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED); // avoid dirty read
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (1,\"JACK\",23);");
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (2,\"Eli\",24);");
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (3,\"Midori\",25);");
            statement.executeBatch();
            connection.commit();

            connection.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED); //avoid update loss problem
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (1,\"JACK\",26);");
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (2,\"Eli\",27);");
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (3,\"Midori\",28);");
            statement.executeBatch();
            connection.commit();

            connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE); // avoid phantom read
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (1,\"JACK\",29);");
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (2,\"Eli\",30);");
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (3,\"Midori\",31);");
            statement.executeBatch();
            connection.commit();

            connection.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ); // avoid non-repeatable reads
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (1,\"JACK\",32);");
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (2,\"Eli\",33);");
            statement.addBatch("INSERT INTO dept20 (employee_id,employee,department_no) VALUES (3,\"Midori\",34);");
            statement.executeBatch();
            connection.commit();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
