package drivermanager.jdbcutil;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

public class JDBCUtil {
    public void printColumnNames(ArrayList<String> columnNames){
        for(String columnName : columnNames){
            System.out.print(columnName);
            System.out.print("\t");
        }
        System.out.println();
    }

    public static ArrayList<String> getColumnNames(ResultSet resultSet) throws SQLException {
        ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
        ArrayList<String> columnNames = new ArrayList<String>();
        int columCount = resultSetMetaData.getColumnCount();
        for(var i=1;i<=columCount;i++){
            columnNames.add(resultSetMetaData.getColumnName(i));
        }
        return columnNames;
    }
}
