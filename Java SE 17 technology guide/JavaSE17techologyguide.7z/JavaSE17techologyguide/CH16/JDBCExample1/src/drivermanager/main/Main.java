package drivermanager.main;

import drivermanager.databaseconnectioninfo.DatabaseConnectionInfo;
import drivermanager.jdbcconnectionutil.JDBCConnectionUtil;

public class Main {
    public static void main(String[] args) throws ClassNotFoundException {
        var JDBCConnectionUtilInst = new JDBCConnectionUtil(DatabaseConnectionInfo.URL,
                DatabaseConnectionInfo.USER,
                DatabaseConnectionInfo.PASSWORD);

        try {
            JDBCConnectionUtilInst.tryToConnect();
            JDBCConnectionUtilInst.tryToClose();
        }catch (Exception ex){
            System.out.println(ex);
        }
    }
}
