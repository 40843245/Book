package drivermanager.jdbcconnectionutil;

import drivermanager.databaseconnectioninfo.DatabaseConnectionInfo;

import java.sql.*;

public class JDBCConnectionUtil {
    public String URL;
    public String USER;
    public String PASSWORD;
    public Connection connection;
    public String sqlCommand;

    public JDBCConnectionUtil(String URL,String USER,String PASSWORD) throws ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        this.URL = URL;
        this.USER = USER;
        this.PASSWORD = PASSWORD;
    }

    public JDBCConnectionUtil() throws ClassNotFoundException {
        this(DatabaseConnectionInfo.URL,DatabaseConnectionInfo.USER,DatabaseConnectionInfo.PASSWORD);
    }

    public void tryToConnect() throws SQLException {
        this.connection = DriverManager.getConnection(this.URL, this.USER, this.PASSWORD);
    }

    public void tryToClose() throws SQLException {
        this.connection.close();
    }
}
