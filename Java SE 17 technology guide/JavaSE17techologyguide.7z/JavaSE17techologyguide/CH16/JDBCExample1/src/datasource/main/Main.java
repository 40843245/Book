package datasource.main;

import datasource.datasourceutil.DataSourceUtil;
import datasource.datasourceutil.MessageInfo;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        var messageinfo = new MessageInfo(new DataSourceUtil());
        System.out.println("name\ttype\tis nullable?\tdefault");
        messageinfo.getAllColumnInfo().forEach(info -> {
                System.out.printf("%s\t%s\t%b\t%s%n",
                        info.name(),
                        info.type(),
                        info.nullable(),
                        info.definition()
                );
        });
    }
}
