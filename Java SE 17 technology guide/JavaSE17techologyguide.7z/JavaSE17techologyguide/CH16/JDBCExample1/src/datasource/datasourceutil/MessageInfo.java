package datasource.datasourceutil;

import java.sql.*;
import java.util.*;
import javax.sql.DataSource;

public class MessageInfo {
    private DataSource dataSource;

    public MessageInfo(DataSource dataSource){
        this.dataSource = dataSource;
    }

    public List<ColumnInfo> getAllColumnInfo(){
        List<ColumnInfo> columnInfos = null;
        try(
                Connection connection = dataSource.getConnection();
                ){
                    DatabaseMetaData metadata = connection.getMetaData();
                    var crs = metadata.getColumns(null,null,"emp",null);
                    columnInfos = new ArrayList<>();
                    while(crs.next()){
                        ColumnInfo columnInfo = toColumnInfo(crs);
                        columnInfos.add(columnInfo);
                    }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return columnInfos;
    }

    private ColumnInfo toColumnInfo(ResultSet crs) throws SQLException {
        var columninfo = new ColumnInfo(
                crs.getString("COLUMN_NAME"),
                crs.getString("TYPE_NAME"),
                crs.getInt("COLUMN_SIZE"),
                crs.getBoolean("IS_NULLABLE"),
                crs.getString("COLUMN_DEF")
    );
        return columninfo;
    }
}
