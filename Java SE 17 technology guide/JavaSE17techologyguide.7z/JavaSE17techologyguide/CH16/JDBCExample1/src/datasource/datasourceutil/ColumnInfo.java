package datasource.datasourceutil;

public record ColumnInfo(
    String name,
    String type,
    int size,
    boolean nullable,
    String definition
){

}
