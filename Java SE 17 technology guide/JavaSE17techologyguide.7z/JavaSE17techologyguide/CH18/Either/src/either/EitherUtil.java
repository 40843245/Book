package either;

import java.util.ArrayList;
import java.util.function.Function;

public class EitherUtil {
    public static Either<String,Integer> div(Integer a,Integer b){
        if(b==0){
            String message = "error due to division of zero. %d / %d.%n".formatted(a,b);
            return new Left<>(message);
        }
        return new Right<>(a/b);
    }

    public static <T,U> Either<String, ArrayList<U>> map(ArrayList<T> source, Function<T,U> transform){
        ArrayList<U> result = new ArrayList<U>();
        try {
            for (T elem : source) {
                result.add(transform.apply(elem));
            }
        }catch (Exception ex){
            String message = String.format("error during the transform function in map method call.%nDetailed message:%n%s",ex.getStackTrace());
            return new Left<>(message);
        }
        return new Right<>(result);
    }

    public static <T,U> Either<String, ArrayList<ArrayList<U>>> mapList(ArrayList<ArrayList<T>> sources, Function<T,U> transform){
        ArrayList<ArrayList<U>> results = new ArrayList<ArrayList<U>>();
        try {
            for (ArrayList<T> source:sources) {
                ArrayList<U> result = new ArrayList<U>();
                for (T elem : source) {
                    result.add(transform.apply(elem));
                }
                results.add(result);
            }
        }catch (Exception ex){
            String message = String.format("error during the transform function in map method call.%nDetailed message:%n%s",ex.getStackTrace());
            return new Left<>(message);
        }
        return new Right<>(results);
    }

    public static <T> Either<String,ArrayList<T>> flat(ArrayList<ArrayList<T>> sources){
        ArrayList<T> result = new ArrayList<T>();
        try{
            for (ArrayList<T> source : sources) {
                source.forEach(elem ->{
                    result.add(elem);
                });
            }
        }catch (Exception ex){
            String message = String.format("error during flatting the source in map flat call.%nDetailed message:%n%s",ex.getStackTrace());
            return new Left<>(message);
        }
        return new Right<>(result);
    }

    public static <S,U> Either<String,ArrayList<U>> flatMap(ArrayList<ArrayList<S>> sources,Function<S,U> transform){
        Either<String, ArrayList<ArrayList<U>>> mappedEither = EitherUtil.mapList(sources,transform);
        if(mappedEither instanceof Left<String, ArrayList<ArrayList<U>>>){
            String message = String.format("error during the execution of flatMap method call.%nDetailed message available at:%n%s%n",mappedEither.left());
            return new Left<String, ArrayList<U>>(message);
        }

        var mappedEitherResult = mappedEither.right();
        Either<String, ArrayList<U>> flattedEither = EitherUtil.flat(mappedEitherResult);

        if(flattedEither instanceof Left<String, ArrayList<U>>){
            String message = String.format("error during the execution of flatMap method call.%nDetailed message available at:%n%s%n",flattedEither.left());
            return new Left<String, ArrayList<U>>(message);
        }

        return new Right<String,ArrayList<U>>(flattedEither.right());
    }

    public static <T,U> Either<T,U> orElse(T elem,U defaultValue){
        if(elem != null){
            return new Left<>(elem);
        }
        return new Right<>(defaultValue);
    }
}
