package either;

public sealed interface Either<E,R> permits Left, Right {
    default E left(){
        throw new IllegalArgumentException("nothing left");
    }

    default R right(){
        throw new IllegalArgumentException("nothing right");
    }
}
