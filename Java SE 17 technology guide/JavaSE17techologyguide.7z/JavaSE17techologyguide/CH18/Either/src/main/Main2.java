package main;

import either.Either;
import either.EitherUtil;
import either.Left;
import either.Right;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class Main2 {

    static Integer inc(int number){
        return number + 1;
    }

    public static void main(String[] args) {
        ArrayList<Integer> source = new ArrayList<Integer>();
        source.add(1);
        source.add(2);
        source.add(3);
        source.add(4);

        Either<String,ArrayList<Integer>> either = EitherUtil.map(source,Main2::inc);

        if(either instanceof Left<String, ArrayList<Integer>>){
            System.err.println(either.left());
        }else if(either instanceof Right<String, ArrayList<Integer>>){
            either.right().forEach(System.out::println);
        }
    }
}
