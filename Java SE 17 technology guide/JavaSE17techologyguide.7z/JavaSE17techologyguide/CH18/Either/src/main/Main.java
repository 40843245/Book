package main;

import either.Either;
import either.EitherUtil;
import either.Left;
import either.Right;

public class Main {

    public static void main(String[] args) {
        Integer a = Integer.parseInt("10");
        Integer b = Integer.parseInt("0");

        Either<String,Integer> either = EitherUtil.div(a,b);

        if(either instanceof Left<String, Integer>){
            System.err.println(either.left());
        }else if(either instanceof Right<String, Integer>){
            System.out.printf("%d / %d = %d.%n",a,b,either.right());
        }
    }
}
