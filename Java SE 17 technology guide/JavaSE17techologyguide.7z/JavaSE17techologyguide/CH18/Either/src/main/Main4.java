package main;

import either.Either;
import either.EitherUtil;
import either.Left;
import either.Right;

import java.util.ArrayList;

public class Main4 {
    public static void main(String[] args) {
        ArrayList<Integer> source = new ArrayList<Integer>();
        source.add(1);
        source.add(null);
        source.add(3);
        source.add(4);

        Either<Integer,Integer> either = EitherUtil.orElse(source.get(1),-100);

        if(either instanceof Left<Integer,Integer>){
            System.err.println(either.left());
        }else if(either instanceof Right<Integer,Integer>){
            System.out.println(either.right());
        }
    }
}
