package main;

import either.Either;
import either.EitherUtil;
import either.Left;
import either.Right;

import java.util.ArrayList;

public class Main3 {

    static Integer inc(int number){
        return number + 1;
    }

    public static void main(String[] args) {
        ArrayList<Integer> source1 = new ArrayList<Integer>();
        source1.add(1);
        source1.add(null);
        source1.add(3);
        source1.add(4);

        ArrayList<Integer> source2 = new ArrayList<Integer>();
        source1.add(5);
        source1.add(null);
        source1.add(7);
        source1.add(8);

        ArrayList<Integer> source3 = new ArrayList<Integer>();
        source1.add(9);
        source1.add(null);
        source1.add(11);
        source1.add(12);

        ArrayList<ArrayList<Integer>> sources = new ArrayList<ArrayList<Integer>>();
        sources.add(source1);
        sources.add(source2);
        sources.add(source3);

        Either<String,ArrayList<Integer>> either = EitherUtil.flatMap(sources,Main3::inc);

        if(either instanceof Left<String,ArrayList<Integer>>){
            System.err.println(either.left());
        }else if(either instanceof Right<String,ArrayList<Integer>>){
            System.out.println(either.right());
        }
    }
}
