package circle;

import java.util.*;

import coordinate2d.Coordinate2D;
import shape.Shape;

public record Circle(Coordinate2D center, double radius) implements Shape{

    @Override
    public double area() {
        return radius*radius*Math.PI;
    }
}
