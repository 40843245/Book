package main;

import circle.Circle;
import coordinate2d.Coordinate2D;
import node.Node;
import nodes.Nodes;
import square.Square;


public class Main {
    public static void main(String[] args) {
        var node1 = new Node<>(new Circle(new Coordinate2D(0.0,0.0),10.0),null);
        var node2 = new Node<>(new Circle(new Coordinate2D(0.0,0.0),20.0),node1);
        var node3 = new Node<>(new Circle(new Coordinate2D(0.0,0.0),30.0),node2);

        var node4 = new Node<>(new Square(new Coordinate2D(0.0,0.0),10.0),null);
        var node5 = new Node<>(new Square(new Coordinate2D(0.0,0.0),20.0),node4);

        Nodes.showNodes(node3);

        Nodes.showNodes(node5);
    }
}
