package nodes;

import node.Node;
import shape.Shape;

public class Nodes {
    public static void showNodes(Node<? extends Shape> node){
        Node<? extends Shape> newNode = node;
        do{
            System.out.println(newNode.value);
            newNode = newNode.next;
        }while(newNode!=null);
    }
}
