package square;

import coordinate2d.Coordinate2D;
import shape.Shape;

public record Square(Coordinate2D center, double length) implements Shape {

    @Override
    public double area() {
        return length*length;
    }
}
