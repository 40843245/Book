package magicalnumbers;

public class MagicalNumbers {
    public static final double EPS = 0.0001;
}
