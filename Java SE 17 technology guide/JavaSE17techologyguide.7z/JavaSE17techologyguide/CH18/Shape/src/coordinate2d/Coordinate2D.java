package coordinate2d;

import magicalnumbers.MagicalNumbers;

public record Coordinate2D(double x, double y){
    public Coordinate2D negate(){
        return this.multiply(-1);
    }

    public Coordinate2D plus(Coordinate2D other){
        return new Coordinate2D(this.x+other.x,this.y+other.y);
    }

    public Coordinate2D minus(Coordinate2D other){
        return this.plus(other.negate());
    }

    public Coordinate2D multiply(double scale){
        return new Coordinate2D(scale * this.x,scale * this.y);
    }

    public Coordinate2D divide(double scale){
        if(Math.abs(scale)<=MagicalNumbers.EPS){
            throw new ArithmeticException("Can not divide by zero.");
        }
        return this.multiply(1/scale);
    }
}
