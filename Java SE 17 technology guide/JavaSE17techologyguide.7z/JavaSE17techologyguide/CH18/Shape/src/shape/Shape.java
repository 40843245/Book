package shape;

public interface Shape {
    double area();
}
