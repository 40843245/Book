package loggerexample1;

public interface Hello {
    void hello(String name);
}
