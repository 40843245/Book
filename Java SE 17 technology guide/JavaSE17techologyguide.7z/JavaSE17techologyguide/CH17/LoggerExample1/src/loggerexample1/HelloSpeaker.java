package loggerexample1;

public class HelloSpeaker implements Hello{
    @Override
    public void hello(String name){
        System.out.printf("Hello, %s.%n",name);
    }
}
