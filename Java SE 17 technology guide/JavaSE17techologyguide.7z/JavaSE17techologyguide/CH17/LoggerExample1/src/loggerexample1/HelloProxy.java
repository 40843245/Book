package loggerexample1;

import java.util.logging.Level;
import java.util.logging.Logger;

public class HelloProxy implements Hello{
    private Hello helloObj;

    public HelloProxy(Hello helloObj){
        this.helloObj = helloObj;
    }

    public void hello(String name){
        log("start to call hello() method.");
        helloObj.hello(name);
        log("start to call hello() method.");
    }

    private void log(String msg){
        Logger.getLogger(HelloProxy.class.getName()).log(Level.INFO,msg);
    }
}
