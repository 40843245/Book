package main;

import loggerexample1.Hello;
import loggerexample1.HelloProxy;
import loggerexample1.HelloSpeaker;

public class Main {
    public static void main(String[] args){
        Hello proxy = new HelloProxy(new HelloSpeaker());
        proxy.hello("Justin");
    }
}
