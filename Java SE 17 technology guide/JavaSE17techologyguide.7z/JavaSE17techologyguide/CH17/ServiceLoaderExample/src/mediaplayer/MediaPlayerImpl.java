package mediaplayer;

public class MediaPlayerImpl implements MediaPlayer{
    @Override
    public void play(String video) {

    }
}
