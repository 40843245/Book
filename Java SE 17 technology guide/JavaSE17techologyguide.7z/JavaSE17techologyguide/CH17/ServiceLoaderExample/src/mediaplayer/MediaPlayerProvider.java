package mediaplayer;

import java.util.ServiceLoader;

public interface MediaPlayerProvider {
    MediaPlayer mediaPlayer();

    public static MediaPlayer provideMediaPlayer(){
        var serviceLoader = ServiceLoader.load(MediaPlayerProvider.class);
        var result = serviceLoader.findFirst().orElseThrow(()->new RuntimeException("No provider.")).mediaPlayer();
        return result;
    }
}
