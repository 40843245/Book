package mediaplayer;

public class MediaPlayerProviderImpl implements MediaPlayerProvider{

    @Override
    public MediaPlayer mediaPlayer() {
        return new MediaPlayer() {
            @Override
            public void play(String video) {
                System.out.printf("The video:`%s` has been played.%n",video);
            }
        };
    }
}
