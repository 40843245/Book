package mediaplayer;

public interface MediaPlayer {
    void play(String video);
}
