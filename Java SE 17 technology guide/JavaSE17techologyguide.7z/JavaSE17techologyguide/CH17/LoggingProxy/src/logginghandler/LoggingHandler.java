package logginghandler;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoggingHandler implements InvocationHandler {

    private Object target;

    public LoggingHandler(Object target) {
        this.target = target;
    }

    @Override
    public Object invoke(Object proxy,
                         Method method,
                         Object[] args
    ) throws Throwable {
        Object result = null;
        try {
            var message = String.format("start to call %s method.",method.getName());
            log(message);
            result = method.invoke(target,args);
            message = String.format("end to call %s method.",method.getName());
            log(message);
        }catch (IllegalAccessException |
                IllegalArgumentException |
                InvocationTargetException ex){
        }
        return result;
    }

    private void log(String message){
        Logger.getLogger(LoggingHandler.class.getName()).log(Level.INFO,message);
    }
}
