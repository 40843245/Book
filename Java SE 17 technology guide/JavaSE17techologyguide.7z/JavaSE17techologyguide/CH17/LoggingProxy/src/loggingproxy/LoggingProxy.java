package loggingproxy;

import logginghandler.LoggingHandler;

import java.lang.reflect.Proxy;

public class LoggingProxy {
    public static Object bind(Object target){
        var cls = target.getClass();
        return Proxy.newProxyInstance(
                cls.getClassLoader(),
                cls.getInterfaces(),
                new LoggingHandler(target)
        );
    }
}
