package classloaderhierarchy;

public class ClassLoaderHierarchy {
    public static void printClassLoaderHierarchyInfo(Class cls){
        System.out.printf("The name of class:%s.%n",cls.getName());
        System.out.printf("cls.getClassLoader:%s.%n",cls.getClassLoader());
        System.out.printf("cls.getClassLoader().getParent():%s.%n",cls.getClassLoader().getParent());
        System.out.printf("cls.getClassLoader().getParent().getParent():%s.%n",cls.getClassLoader().getParent().getParent());
    }
}
