package main;

import classloaderhierarchy.ClassLoaderHierarchy;

public class Main {
    public static void main(String[] args){
        var cls = ClassLoaderHierarchy.class;
        ClassLoaderHierarchy.printClassLoaderHierarchyInfo(cls);
    }
}
