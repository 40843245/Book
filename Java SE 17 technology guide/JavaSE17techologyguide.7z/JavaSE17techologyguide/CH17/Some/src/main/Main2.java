package main;

import java.lang.reflect.Constructor;

public class Main2 {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException {
        var cls = Class.forName("some.Some");
        Constructor constructor = cls.getDeclaredConstructor(String.class);
    }
}
