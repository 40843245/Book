package main;

import some.Some;

public class Main {
    public static void main(String[] args) throws ClassNotFoundException {
        var cls = Class.forName("some.Some");
    }
}
