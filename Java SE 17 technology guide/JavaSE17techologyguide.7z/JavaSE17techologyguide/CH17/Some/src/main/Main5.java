package main;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Main5 {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        var cls = Class.forName("some.Some");
        Constructor constructor = cls.getDeclaredConstructor(String.class);
        var target = constructor.newInstance("Some Object");
        cls.getDeclaredMethod("doSome").invoke(target);
        var field = cls.getDeclaredField("some");
    }
}
