package main;

import classloaderutil.ClassLoaderUtil;
import classutil.ClassUtil;

import java.net.MalformedURLException;

public class Main {
    public static void main(String[] args) throws MalformedURLException, ClassNotFoundException {
        var methodName = "quick";
        var loadedClass = ClassLoaderUtil.loadClassFrom(args[1],args[2]);
        var loadedMethod = ClassUtil.getMethodInAllWay(loadedClass,methodName);
    }
}
