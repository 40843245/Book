package classutil;

import java.lang.reflect.Method;

public class ClassUtil {
    public static Method getMethodInAllWay(Class cls,String methodName){
        Method method = null;
        try {
            method = ClassUtil.getMethod(cls, methodName);
        } catch (NoSuchMethodException ex) {
            System.out.println("No such method.");
            method = null;
        }

        if(method!=null){
            return method;
        }

        try {
            method = ClassUtil.getDeclaredMethod(cls, methodName);
        } catch (NoSuchMethodException ex) {
            System.out.println("No such method.");
            method = null;
        }

        if(method!=null){
            return method;
        }

        return null;
    }

    public static Method getMethod(Class cls,String methodName) throws NoSuchMethodException {
        return cls.getMethod(methodName);
    }

    public static Method getDeclaredMethod(Class cls,String methodName) throws NoSuchMethodException {
        return cls.getDeclaredMethod(methodName);
    }
}
