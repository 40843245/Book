package classinfo;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;

public class ClassInfo {
    public static void printClassesInfo(Class[] classes) {
        System.out.println("In printClassesInfo method.");
        for(Class cls:classes){
            ClassInfo.printClassInfo(cls);
        }
    }
    public static void printClassInfo(Class cls){
        try {
            System.out.printf("the class name:`%s`%n", cls.getName());
            System.out.printf("the class canonical name:`%s`%n", cls.getCanonicalName());
            System.out.printf("the class package name through getPackage().getName() :`%s`%n", cls.getPackage().getName());
            System.out.printf("the class package name through getPackageName():`%s`%n", cls.getPackageName());
            System.out.printf("Is the class interface?`%b`.%n", cls.isInterface());
            System.out.printf("Is the class the primitive type?`%b`.%n", cls.isPrimitive());
            System.out.printf("Is the class the array?`%b`.%n", cls.isArray());
            System.out.printf("Super class name:`%s`.%n", cls.getSuperclass().getName());
            System.out.printf("It is located at the module:`%s`.%n", cls.getModule().getName());

            var classes = cls.getClasses();
            System.out.printf("To print all classes of class:`%s`.%n", cls.getName());
            ClassInfo.printClassesName(classes);

            var declaredClasses = cls.getDeclaredClasses();
            System.out.printf("To print all declared classes of class:`%s`.%n", cls.getName());
            ClassInfo.printClassesName(declaredClasses);

            var fields = cls.getFields();
            ClassInfo.printFieldsInfo(fields);

        }catch (Exception ex){
            System.out.println(ex.getStackTrace());
        }
    }

    public static void printClassesName(Class[] classes){
        System.out.println("In printClassesName method.");
        for(Class cls:classes){
            System.out.printf("The class name:%s",cls.getName());
        }
    }

    public static void printClassModifier(Class cls){
        int modifier= cls.getModifiers();
        System.out.printf("the modifier of the class:`%s`%n", Modifier.toString(modifier));
    }

    public static void printFieldsInfo(Field[] fields){
        System.out.println("In printFieldsInfo method.");
        for(Field field: fields){
            ClassInfo.printFieldInfo(field);
        }
    }

    public static void printFieldInfo(Field field){
        System.out.printf("the field name is:`%s`.%n",field.getName());
        ClassInfo.printFieldModifier(field);
    }

    public static void printFieldModifier(Field field){
        int modifier = field.getModifiers();
        System.out.printf("The modifier of the field is:`%s`.%n",Modifier.toString(modifier));
    }

    public static void printTypesInfo(Type[] types){
        System.out.println("In printTypesInfo method.");
        for(Type type: types){
            ClassInfo.printTypeInfo(type);
        }
    }

    public static void printTypeInfo(Type type){
        System.out.printf("the type name is:`%s`.%n",type.getTypeName());
    }

    public static void printMethodsInfo(Method[] methods){
        System.out.println("In printMethodsInfo method.");
        for(Method method: methods){
            ClassInfo.printMethodInfo(method);
        }
    }

    public static void printMethodInfo(Method method){
        System.out.printf("the name of method  is:`%s`.%n",method.getName());
        System.out.printf("the generic name of method is:`%s`.%n",method.toGenericString());
        System.out.printf("the default value of method is:`%s`.%n",method.getDefaultValue().toString());
        System.out.printf("the returned type of method is:`%s`.%n",method.getReturnType().toString());
        System.out.printf("the generic returned type of method is:`%s`.%n",method.getGenericReturnType().toString());

        var declaredAnnotations = method.getDeclaredAnnotations();
        ClassInfo.printAnnotationsInfo(declaredAnnotations);

        var exceptionTypes=method.getExceptionTypes();
        ClassInfo.printClassesInfo(exceptionTypes);
    }

    public static void printAnnotationsInfo(Annotation[] annotations){
        System.out.println("In printAnnotationsInfo method.");
        for(Annotation annotation: annotations){
            ClassInfo.printAnnotationInfo(annotation);
        }
    }

    public static void printAnnotationInfo(Annotation annotation){
        System.out.printf("The annotation:`%s`.%n",annotation.toString());
    }
}
