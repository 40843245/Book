package classexample1;

import java.lang.reflect.InvocationTargetException;

public class ClassExample1 {
    public static void forName(String clsName) throws ClassNotFoundException {
        Class.forName(clsName);
    }

    public static void printConstructor(String clsName) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        var cls = Class.forName(clsName);
        var clsInst = cls.getConstructor().newInstance();
        var clsDeclaredInst = cls.getDeclaredConstructor().newInstance();

        System.out.printf("clsInst name:`%s`%n",clsInst.getClass().getName());
        System.out.printf("clsDeclaredInst name:`%s`%n",clsDeclaredInst.getClass().getName());
    }
}
