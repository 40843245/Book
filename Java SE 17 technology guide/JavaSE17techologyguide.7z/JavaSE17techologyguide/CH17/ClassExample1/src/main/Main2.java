package main;

import classexample1.ClassExample1;

public class Main2 {
    public static void main(String[] args) throws ClassNotFoundException {
        ClassExample1.forName("jdbc:driver");
    }
}
