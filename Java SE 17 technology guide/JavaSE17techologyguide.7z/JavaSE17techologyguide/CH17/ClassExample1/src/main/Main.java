package main;

import classinfo.ClassInfo;

public class Main {
    public static void main(String[] args){
        Class[] classes= new Class[]{
                Short.class,
                short.class,
                Byte.class,
                byte.class,
                Integer.class,
                int.class,
                Long.class,
                long.class,
                Float.class,
                float.class,
                Double.class,
                double.class,
                Boolean.class,
                boolean.class,
                Character.class,
                char.class,
                String.class,
                Class.class,
        };

        for(Class cls : classes){
            ClassInfo.printClassInfo(cls);
        }
    }
}
