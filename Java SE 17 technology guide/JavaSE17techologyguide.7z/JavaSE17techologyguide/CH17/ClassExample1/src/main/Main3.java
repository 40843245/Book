package main;

import classexample1.ClassExample1;

import java.lang.reflect.InvocationTargetException;

public class Main3 {
    public static void main(String[] args) throws ClassNotFoundException, InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        ClassExample1.printConstructor("jdbc::driver");
    }
}
