package classloaderutil;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

public class ClassLoaderUtil {
    public static Class loadClassFrom(String path,String className) throws MalformedURLException, ClassNotFoundException {
        var loader = new URLClassLoader(new URL[]{new URL(path)});
        return loader.loadClass(className);
    }
}
