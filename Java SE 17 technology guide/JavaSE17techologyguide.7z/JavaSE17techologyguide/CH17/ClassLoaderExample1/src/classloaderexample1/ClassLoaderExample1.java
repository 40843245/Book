package classloaderexample1;

import classloaderutil.ClassLoaderUtil;

import java.net.MalformedURLException;

public class ClassLoaderExample1 {
    public static void printClassLoaderInfo(String[] args){
        try {
            var path = args[0];
            var className = args[1];

            var cls1 = ClassLoaderUtil.loadClassFrom(path, className);
            System.out.println(cls1);
            var cls2 = ClassLoaderUtil.loadClassFrom(path, className);
            System.out.println(cls2);

            System.out.printf("Are cls1 and cls2 equivalent?`%b`.%n",cls1==cls2);
        }catch (ArrayIndexOutOfBoundsException ex){
            System.out.println("Either no specified such class path and no such specified name to load.");
        } catch (MalformedURLException ex){
            System.out.println("Wrong path to load.");
        }catch (ClassNotFoundException ex){
            System.out.println("Can NOT find specified class to load.");
        }
    }
}
