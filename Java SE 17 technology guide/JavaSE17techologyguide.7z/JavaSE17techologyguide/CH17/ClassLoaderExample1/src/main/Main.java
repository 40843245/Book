package main;

import classloaderexample1.ClassLoaderExample1;

public class Main {
    public static void main(String[] args){
        ClassLoaderExample1.printClassLoaderInfo(args);
    }
}
