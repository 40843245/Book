package main;

import source.Student;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        var cls = Student.class;
        var obj = cls.getDeclaredConstructor().newInstance();
        Field name = cls.getDeclaredField("name");
        Field score = cls.getDeclaredField("score");
        name.setAccessible(true);
        score.setAccessible(true);
        name.set(obj,"Justin");
        score.set(obj,90);
        var student = (Student) obj;
        System.out.printf("(%s,%d).%n",student.getName(),student.getScore());
    }
}
