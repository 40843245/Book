package beanutil;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.Map;

public class BeanUtil {
    public static <T> T getBean(Map<String,Object> data, String className) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        var cls = Class.forName(className);
        var bean = cls.getDeclaredConstructor().newInstance();

        data.entrySet().forEach(entry->{
            var setter = String.format("set%s%s",
                    entry.getKey().substring(0,1).toUpperCase(),
                    entry.getKey().substring(1)
                    );
            try{
                var method = cls.getMethod(setter,entry.getValue().getClass());
                if(Modifier.isPublic(method.getModifiers())){
                    method.invoke(bean,entry.getValue());
                }
            } catch (NoSuchMethodException |
                     IllegalArgumentException |
                     IllegalAccessException |
                     SecurityException |
                     InvocationTargetException ex
            ) {
                throw new RuntimeException(ex);
            }
        });
        return (T) bean;
    }
}
