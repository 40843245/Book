package main;

public class Main2 {
    public static void main(String[] args) throws InterruptedException {
        c();
    }

    private static void c(){
        b();
    }

    private static void b(){
        a();
    }

    private static void a(){
        StackWalker stackWalker = StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE);
        System.out.printf("Caller class: `%s`.%n",stackWalker.getCallerClass().getName());
        stackWalker.forEach(System.out::println);

        stackWalker.forEach(stackFrame -> {
            System.out.printf("stackFrame.getDeclaringClass():`%s`,stackFrame.getMethodName():`%s`,stackFrame.getClassName():`%s`.%n",stackFrame.getDeclaringClass(),stackFrame.getMethodName(),stackFrame.getClassName());
        });
    }
}
