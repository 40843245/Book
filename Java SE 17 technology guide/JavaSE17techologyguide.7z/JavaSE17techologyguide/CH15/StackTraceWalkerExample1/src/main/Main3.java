package main;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

public class Main3 {
    public static void main(String[] args) throws InterruptedException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Main3.class.getDeclaredMethod("c").invoke(null);
    }

    private static void c(){
        b();
    }

    private static void b(){
        a();
    }

    private static void a(){
        List<StackWalker> stackWalkers = List.of(
                StackWalker.getInstance(),
                StackWalker.getInstance(StackWalker.Option.SHOW_REFLECT_FRAMES),
                StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE),
                StackWalker.getInstance(StackWalker.Option.SHOW_HIDDEN_FRAMES)
        );

        stackWalkers.forEach(stackWalker -> {
            System.out.println();
            stackWalker.forEach(System.out::println);
        });
    }
}
