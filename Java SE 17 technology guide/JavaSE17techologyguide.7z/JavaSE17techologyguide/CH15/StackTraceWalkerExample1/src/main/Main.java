package main;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        c();
    }

    private static void c(){
        b();
    }

    private static void b(){
        a();
    }

    private static void a(){
        StackWalker stackWalker = StackWalker.getInstance();
        stackWalker.forEach(System.out::println);
    }
}
