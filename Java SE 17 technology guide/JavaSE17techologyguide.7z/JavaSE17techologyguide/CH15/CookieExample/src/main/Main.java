package main;

import cookieexample.CookieExample1;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        String uri1ForCookieManager = "https://www.ptt.cc";
        String uri1Tag = "over18";
        String gossipUri1 = "https://www.ptt.cc//bbs/Gossiping/index.html";

        CookieExample1.CookieHandler(uri1ForCookieManager,uri1Tag,gossipUri1);
    }
}
