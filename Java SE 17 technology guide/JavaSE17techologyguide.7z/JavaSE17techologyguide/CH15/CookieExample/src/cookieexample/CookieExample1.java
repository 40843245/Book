package cookieexample;

import java.io.IOException;
import java.net.CookieManager;
import java.net.HttpCookie;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class CookieExample1 {
    public static void CookieHandler(String uri1ForCookieManager,String uri1Tag,String gossipUri1) throws IOException, InterruptedException {
        var cookieTag1 = new HttpCookie(uri1Tag,"1");
        cookieTag1.setPath("/");

        var cookieManager = new CookieManager();
        cookieManager.getCookieStore().add(URI.create(uri1ForCookieManager),cookieTag1);

        var gossip = URI.create(gossipUri1);

        var request = HttpRequest.newBuilder(gossip).build();

        var client = HttpClient
                .newBuilder()
                .cookieHandler(cookieManager)
                .build();

        System.out.println(client.send(request, HttpResponse.BodyHandlers.ofString()).body());
    }
}
