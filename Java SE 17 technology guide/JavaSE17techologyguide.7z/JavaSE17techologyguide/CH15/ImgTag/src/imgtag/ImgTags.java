package imgtag;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.regex.Pattern;

public class ImgTags {
    public static void tagImg(String[] args){
        var regex= Pattern.compile("(?s)<img.+?scr=\"(.+?)\".*?>");
        var request = HttpRequest.newBuilder().uri(URI.create(args[0]));
        HttpClient.newHttpClient()
                .sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(resp->resp.body())
                .thenAccept(html->{
                   var matcher = regex.matcher(html);
                   while(matcher.find()){
                       System.out.println(matcher.group());
                   }
                }).join();

    }
}
