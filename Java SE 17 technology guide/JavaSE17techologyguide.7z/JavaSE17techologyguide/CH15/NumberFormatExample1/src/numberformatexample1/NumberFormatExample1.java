package numberformatexample1;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class NumberFormatExample1 {
    public static void printAllKindsOfInstance(double number1) {
        NumberFormatExample1.printInstanceWithoutCurrencyAnnotation(number1);
        NumberFormatExample1.printInstanceWithCurrencyAnnotation(number1);
        NumberFormatExample1.printInstanceWhichOnlyFormatToIntegerDigit(number1);
        NumberFormatExample1.printInstanceWithSeperatedByFourDigitsForIntegerAndFourDigitsFourFloatingPoint(number1);
        NumberFormatExample1.printInstanceWithSeperatedByFourDigitsForIntegerAndThreeDigitsForFloatingPoint(number1);
        NumberFormatExample1.printInstanceWithSeperatedByFourDigitsForIntegerAndThreeDigitsForFloatingPointWhichPaddedByZero(number1);
    }

    public static void printInstanceWithoutCurrencyAnnotation(double number1) {
        var inst = NumberFormat.getInstance();
        var prcInst = NumberFormat.getInstance(Locale.PRC);
        var rootInst = NumberFormat.getInstance(Locale.ROOT);
        var japanInst = NumberFormat.getInstance(Locale.JAPAN);
        var japaneseInst = NumberFormat.getInstance(Locale.JAPANESE);
        var koreaInst = NumberFormat.getInstance(Locale.KOREA);
        var koreanInst = NumberFormat.getInstance(Locale.KOREAN);
        var chinaInst = NumberFormat.getInstance(Locale.CHINA);
        var taiwanInst = NumberFormat.getInstance(Locale.TAIWAN);
        var simplified_chineseInst = NumberFormat.getInstance(Locale.SIMPLIFIED_CHINESE);
        var traditional_chineseInst = NumberFormat.getInstance(Locale.TRADITIONAL_CHINESE);
        var chineseInst = NumberFormat.getInstance(Locale.CHINESE);
        var ukInst = NumberFormat.getInstance(Locale.UK);
        var usInst = NumberFormat.getInstance(Locale.US);
        var englishInst = NumberFormat.getInstance(Locale.ENGLISH);
        var canadaInst = NumberFormat.getInstance(Locale.CANADA);
        var cananda_frenchInst = NumberFormat.getInstance(Locale.CANADA_FRENCH);
        var franceInst = NumberFormat.getInstance(Locale.FRANCE);
        var frenchInst = NumberFormat.getInstance(Locale.FRENCH);
        var germanInst = NumberFormat.getInstance(Locale.GERMAN);
        var germanyInst = NumberFormat.getInstance(Locale.GERMANY);
        var italyInst = NumberFormat.getInstance(Locale.ITALY);
        var italianInst = NumberFormat.getInstance(Locale.ITALIAN);

        System.out.printf("About the number number1:`%f`.%n", number1);

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.printf("Format the number number1:`%f` without currency annotation.%n", number1);

        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in default mode without currency annotation.%n", number1, inst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.PRC mode without currency annotation.%n", number1, prcInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.ROOT mode without currency annotation.%n", number1, rootInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.JAPAN mode without currency annotation.%n", number1, japanInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.JAPANESE mode without currency annotation.%n", number1, japaneseInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.KOREA mode without currency annotation.%n", number1, koreaInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.KOREAN mode without currency annotation.%n", number1, koreanInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.CHINA mode without currency annotation.%n", number1, chinaInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.TAIWAN mode without currency annotation.%n", number1, taiwanInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.SIMPLIFIED_CHINESE mode without currency annotation.%n", number1, simplified_chineseInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.TRADITIONAL_CHINESE mode without currency annotation.%n", number1, traditional_chineseInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.CHINESE mode without currency annotation.%n", number1, chineseInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.UK mode without currency annotation.%n", number1, ukInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.US mode without currency annotation.%n", number1, usInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.ENGLISH mode without currency annotation.%n", number1, englishInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.CANADA mode without currency annotation.%n", number1, canadaInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.CANADA_FRENCH mode without currency annotation.%n", number1, cananda_frenchInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.FRANCE mode without currency annotation.%n", number1, franceInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.FRENCH mode without currency annotation.%n", number1, frenchInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.GERMAN mode without currency annotation.%n", number1, germanInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.GERMANY mode without currency annotation.%n", number1, germanyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.ITALY mode without currency annotation.%n", number1, italyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.ITALIAN mode without currency annotation.%n", number1, italianInst.format(number1));
    }

    public static void printInstanceWithCurrencyAnnotation(double number1) {
        var currencyInst = NumberFormat.getInstance();
        var prcCurrencyInst = NumberFormat.getCurrencyInstance(Locale.PRC);
        var rootCurrencyInst = NumberFormat.getCurrencyInstance(Locale.ROOT);
        var japanCurrencyInst = NumberFormat.getCurrencyInstance(Locale.JAPAN);
        var japaneseCurrencyInst = NumberFormat.getCurrencyInstance(Locale.JAPANESE);
        var koreaCurrencyInst = NumberFormat.getCurrencyInstance(Locale.KOREA);
        var koreanCurrencyInst = NumberFormat.getCurrencyInstance(Locale.KOREAN);
        var chinaCurrencyInst = NumberFormat.getCurrencyInstance(Locale.CHINA);
        var taiwanCurrencyInst = NumberFormat.getCurrencyInstance(Locale.TAIWAN);
        var simplified_chineseCurrencyInst = NumberFormat.getCurrencyInstance(Locale.SIMPLIFIED_CHINESE);
        var traditional_chineseCurrencyInst = NumberFormat.getCurrencyInstance(Locale.TRADITIONAL_CHINESE);
        var chineseCurrencyInst = NumberFormat.getCurrencyInstance(Locale.CHINESE);
        var ukCurrencyInst = NumberFormat.getCurrencyInstance(Locale.UK);
        var usCurrencyInst = NumberFormat.getCurrencyInstance(Locale.US);
        var englishCurrencyInst = NumberFormat.getCurrencyInstance(Locale.ENGLISH);
        var canadaCurrencyInst = NumberFormat.getCurrencyInstance(Locale.CANADA);
        var cananda_frenchCurrencyInst = NumberFormat.getCurrencyInstance(Locale.CANADA_FRENCH);
        var franceCurrencyInst = NumberFormat.getCurrencyInstance(Locale.FRANCE);
        var frenchCurrencyInst = NumberFormat.getCurrencyInstance(Locale.FRENCH);
        var germanCurrencyInst = NumberFormat.getCurrencyInstance(Locale.GERMAN);
        var germanyCurrencyInst = NumberFormat.getCurrencyInstance(Locale.GERMANY);
        var italyCurrencyInst = NumberFormat.getCurrencyInstance(Locale.ITALY);
        var italianCurrencyInst = NumberFormat.getCurrencyInstance(Locale.ITALIAN);

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.printf("Format the number number1:`%f` with currency annotation.%n", number1);

        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in default mode with currency annotation.%n", number1, currencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.PRC mode with currency annotation.%n", number1, prcCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.ROOT mode with currency annotation.%n", number1, rootCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.JAPAN mode with currency annotation.%n", number1, japanCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.JAPANESE mode with currency annotation.%n", number1, japaneseCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.KOREA mode with currency annotation.%n", number1, koreaCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.KOREAN mode with currency annotation.%n", number1, koreanCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.CHINA mode with currency annotation.%n", number1, chinaCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.TAIWAN mode with currency annotation.%n", number1, taiwanCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.SIMPLIFIED_CHINESE mode with currency annotation.%n", number1, simplified_chineseCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.TRADITIONAL_CHINESE mode with currency annotation.%n", number1, traditional_chineseCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.CHINESE mode with currency annotation.%n", number1, chineseCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.UK mode with currency annotation.%n", number1, ukCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.US mode with currency annotation.%n", number1, usCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.ENGLISH mode with currency annotation.%n", number1, englishCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.CANADA mode with currency annotation.%n", number1, canadaCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.CANADA_FRENCH mode with currency annotation.%n", number1, cananda_frenchCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.FRANCE mode with currency annotation.%n", number1, franceCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.FRENCH mode with currency annotation.%n", number1, frenchCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.GERMAN mode with currency annotation.%n", number1, germanCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.GERMANY mode with currency annotation.%n", number1, germanyCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.ITALY mode with currency annotation.%n", number1, italyCurrencyInst.format(number1));
        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in Locale.ITALIAN mode with currency annotation.%n", number1, italianCurrencyInst.format(number1));
    }

    public static void printInstanceWhichOnlyFormatToIntegerDigit(double number1) {
        var formatter = new DecimalFormat();
        formatter.setParseIntegerOnly(true);
        var formattedNumber1 = formatter.format(number1);

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.printf("Format the number number1:`%f` without currency annotation where sperated by four digits for integer parts and seperated three digits for floating point.%n", number1);

        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in default mode without currency annotation.%n", number1, formattedNumber1);
    }

    public static void printInstanceWithSeperatedByFourDigitsForIntegerAndFourDigitsFourFloatingPoint(double number1) {
        var formatter = new DecimalFormat("#,####.####");
        formatter.setDecimalSeparatorAlwaysShown(true);
        var formattedNumber1 = formatter.format(number1);

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.printf("Format the number number1:`%f` without currency annotation where sperated by four digits for integer parts and seperated three digits for floating point.%n", number1);

        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in default mode without currency annotation.%n", number1, formattedNumber1);
    }

    public static void printInstanceWithSeperatedByFourDigitsForIntegerAndThreeDigitsForFloatingPoint(double number1) {
        var formatter = new DecimalFormat("#,####.###");
        formatter.setDecimalSeparatorAlwaysShown(true);
        var formattedNumber1 = formatter.format(number1);

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.printf("Format the number number1:`%f` without currency annotation where sperated by three digits for integer parts and seperated three digits for floating point.%n", number1);

        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in default mode without currency annotation.%n", number1, formattedNumber1);
    }

    public static void printInstanceWithSeperatedByFourDigitsForIntegerAndThreeDigitsForFloatingPointWhichPaddedByZero(double number1) {
        var formatter = new DecimalFormat("#,####.000");
        formatter.setDecimalSeparatorAlwaysShown(true);
        var formattedNumber1 = formatter.format(number1);

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.printf("Format the number number1:`%f` without currency annotation where sperated by four digits for integer parts and seperated three digits for floating point parts and padding with zero if neccessary.%n", number1);

        System.out.printf("Unformatted number1:`%f`, formatted number1:`%s` with class in default mode without currency annotation.%n", number1, formattedNumber1);
    }
}