package main;

import numberformatexample1.NumberFormatExample1;

public class Main {
    public static void main(String[] args){
        var doubleNumbers = new double[]{
          0.0d, -0.0d, 2.0d, 12345.0d, 123456789.123456789d, -12345.0d,
        };

        for(var doubleNumber : doubleNumbers) {
            System.out.println("-----------------------------");
            NumberFormatExample1.printAllKindsOfInstance(doubleNumber);
        }
    }
}
