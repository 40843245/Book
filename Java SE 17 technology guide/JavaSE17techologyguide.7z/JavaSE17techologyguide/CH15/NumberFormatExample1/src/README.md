# Java
## NumberFormat
### intro 
To format a number (without currency annotation and with currency annotation)

### API reference
[NumberFormat](https://docs.oracle.com/javase/8/docs/api/java/text/NumberFormat.html#format-double-java.lang.StringBuffer-java.text.FieldPosition-)