package stacktraceelementexample1;

import stacktraceelementutil.StackTraceElementUtil;

public class StackTraceElementExample1 {
    public static void printStackTraceElementInAllWay(){
        StackTraceElement[] stackTraceElements1 = StackTraceElementUtil.getStackTraceWay1();
        StackTraceElement[] stackTraceElements2 = StackTraceElementUtil.getStackTraceWay2();

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~");
        StackTraceElementExample1.printStackTraceElement(stackTraceElements1);
        StackTraceElementExample1.printStackTraceElement(stackTraceElements1);
    }

    public static void printStackTraceElement(StackTraceElement[] stackTraceElements){
        System.out.println("----------------------");
        for(var stackTraceElement: stackTraceElements){
            System.out.println(stackTraceElement);
        }
    }
}
