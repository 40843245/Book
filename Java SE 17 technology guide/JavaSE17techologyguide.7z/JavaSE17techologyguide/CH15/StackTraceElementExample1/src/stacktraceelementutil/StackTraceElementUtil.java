package stacktraceelementutil;

public class StackTraceElementUtil {
    public static StackTraceElement[] getStackTraceWay1(){
            return new Throwable().getStackTrace();
    }

    public static StackTraceElement[] getStackTraceWay2(){
        return Thread.currentThread().getStackTrace();
    }
}
