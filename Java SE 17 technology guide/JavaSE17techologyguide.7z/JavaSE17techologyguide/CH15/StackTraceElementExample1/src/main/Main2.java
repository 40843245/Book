package main;

import stacktraceelementexample1.StackTraceElementExample1;

public class Main2 {
    public static void main(String[] args) throws InterruptedException {
        var newThread = new Thread(()->c());
        newThread.start();
        newThread.join();
        c();
    }

    private static void c(){
        b();
    }

    private static void b(){
        a();
    }

    private static void a(){
        StackTraceElementExample1.printStackTraceElementInAllWay();
    }
}
