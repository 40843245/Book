package htmltaghandler;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.LeafNode;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

import java.util.*;

public class JsoupHandler {
    public static Elements removeTagsInsideATag(Document document, String insideTag, String tagNameToRemove){
        Elements tagNameToRemoveElements = document.getElementsByTag(tagNameToRemove);
        tagNameToRemoveElements.replaceAll(tagNameToRemoveElement -> {
            Elements insideTagElements = tagNameToRemoveElement.getElementsByTag(insideTag);
            if(!insideTagElements.isEmpty()){
                var tagNameToRemoveElementText = tagNameToRemoveElement.text();
                var newElement = new Element(insideTag);
                newElement.text(tagNameToRemoveElementText).clone();
                return newElement.clone();
            }
            return tagNameToRemoveElement.clone();
        });
        return tagNameToRemoveElements;
    }
}