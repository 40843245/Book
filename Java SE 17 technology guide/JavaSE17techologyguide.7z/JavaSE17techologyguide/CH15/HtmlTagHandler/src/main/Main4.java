package main;

import htmltaghandler.JsoupHandler;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main4 {
    public static void main(String[] args) throws IOException {
        String inputFileName = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH15\\HtmlTagHandler\\src\\data\\input\\html\\testdata1.html";
        Path inputFilePath = Paths.get(inputFileName);
        File inputFile = inputFilePath.toFile();
        Document document = Jsoup.parse(inputFile);
        Elements elements = JsoupHandler.removeTagsInsideATag(document,"img","a");
        System.out.println(elements);

        String outputFileName = "C:\\Users\\40843\\OneDrive\\桌面\\TibaMe\\Java\\JavaSE17techologyguide\\CH15\\HtmlTagHandler\\src\\data\\output\\html\\testdata1.html";
        Path outputFilePath = Paths.get(outputFileName);
        if(Files.notExists(outputFilePath)){
            Files.createFile(outputFilePath);
        }

        FileWriter fileWriter = new FileWriter(outputFilePath.toFile());
        fileWriter.write(elements.toString());
        fileWriter.close();
    }
}
