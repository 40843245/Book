# Exercise 15-1
## Solution
### Tip to solve it
> [!TIP]
> + Use `jsoup` Java package.
> 
> + Use replaceAll method in Elements instance to replace the text for each Element instance.
> 
> See [replaceAll method](https://jsoup.org/apidocs/org/jsoup/select/Elements.html#replaceAll(java.util.function.UnaryOperator))
> 
> + Use text(String text) method in Element instance to create a new instacne of Element according the original Element instance and set the text of it.
> 
> See [text(String text) method](https://jsoup.org/apidocs/org/jsoup/nodes/Element.html#text(java.lang.String))

### reference
#### URI of document 
+ For document of Jsoup, see [Jsoup](https://jsoup.org/)

#### URI to download 
+ To download Jsoup from `Maven`, visit [Jsoup](https://mvnrepository.com/artifact/org.jsoup/jsoup)
