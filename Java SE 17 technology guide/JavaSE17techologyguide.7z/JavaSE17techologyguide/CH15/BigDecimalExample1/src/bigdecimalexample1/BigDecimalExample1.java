package bigdecimalexample1;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class BigDecimalExample1 {
    public static void printResultAfterRounding(int number, int scale, RoundingMode roundingMode){
        var result = BigDecimalUtil.rounding(number, scale, roundingMode);
        System.out.printf("The number:%d after rounding with rounding mode:%s on %dth floating point is %s.%n",number,roundingMode.toString(),-scale,result.toPlainString());
    }

    public static void printResultAfterRounding(long number, int scale, RoundingMode roundingMode){
        var result = BigDecimalUtil.rounding(number,scale,roundingMode);
        System.out.printf("The number:%S after rounding with rounding mode:%s on %dth floating point is %s.%n",String.valueOf(number),roundingMode.toString(),-scale,result.toPlainString());
    }

    public static void printResultAfterRounding(short number, int scale, RoundingMode roundingMode){
        var result = BigDecimalUtil.rounding(number,scale,roundingMode);
        System.out.printf("The number:%d after rounding with rounding mode:%s on %dth floating point is %s.%n",number,roundingMode.toString(),-scale,result.toPlainString());
    }

    public static void printResultAfterRounding(float number, int scale, RoundingMode roundingMode){
        var result = BigDecimalUtil.rounding(number,scale,roundingMode);
        System.out.printf("The number:%f after rounding with rounding mode:%s on %dth floating point is %s.%n",number,roundingMode.toString(),-scale,result.toPlainString());
    }

    public static void printResultAfterRounding(double number, int scale, RoundingMode roundingMode){
        var result = BigDecimalUtil.rounding(number,scale,roundingMode);
        System.out.printf("The number:%s after rounding with rounding mode:%s on %dth floating point is %s.%n",String.valueOf(number),roundingMode.toString(),-scale,result.toPlainString());
    }

    public static void printResultAfterRounding(BigDecimal number, int scale, RoundingMode roundingMode){
        var result = BigDecimalUtil.rounding(number,scale,roundingMode);
        System.out.printf("The number:%s after rounding with rounding mode:%s on %dth floating point is %s.%n",number.toPlainString(),roundingMode.toString(),-scale,result.toPlainString());
    }

    public static void printResultAfterAdding(BigDecimal number1,BigDecimal number2){
        BigDecimal number3 = number1.add(number2);
        System.out.printf("big number number1:`%s` + big number number2:`%s` = big number number3:`%s`.%n",number1.toPlainString(),number2.toPlainString(),number3.toPlainString());
    }

    public static void printResultAfterSubtracting(BigDecimal number1,BigDecimal number2){
        BigDecimal number3 = number1.subtract(number2);
        System.out.printf("big number number1:`%s` - big number number2:`%s` = big number number3:`%s`.%n",number1.toPlainString(),number2.toPlainString(),number3.toPlainString());
    }

    public static void printResultAfterMultiplying(BigDecimal number1,BigDecimal number2){
        BigDecimal number3 = number1.subtract(number2);
        System.out.printf("big number number1:`%s` * big number number2:`%s` = big number number3:`%s`.%n",number1.toPlainString(),number2.toPlainString(),number3.toPlainString());
    }

    public static void printResultAfterDividingAndRemaining(BigDecimal number1,BigDecimal number2){
        BigDecimal[] number3 = number1.divideAndRemainder(number2);
        System.out.printf("big number number1:`%s` / big number number2:`%s` = big number number3:`%s`.%n",number1.toPlainString(),number2.toPlainString(),number3[0].toPlainString());
        System.out.printf("big number number1:`%s` %% big number number2:`%s` = big number number3:`%s.%n`",number1.toPlainString(),number2.toPlainString(),number3[1].toPlainString());
    }

    public static void printResultAfterPowing(BigDecimal number1,BigDecimal number2){
        BigDecimal roundedNumber1 = number1.setScale(0,RoundingMode.FLOOR);
        BigDecimal roundedNumber2 = number2.setScale(0,RoundingMode.FLOOR);
        BigDecimal number3 = roundedNumber1.pow(roundedNumber2.intValueExact());
        System.out.printf("big number number1:`%s` ^ rounding of big number number2:`%d` = big number number3:`%s`.%n",roundedNumber1.toPlainString(),roundedNumber2.intValueExact(),number3.toPlainString());
    }

    public static void printResultAfterAbsing(BigDecimal number1){
        BigDecimal number3 = number1.abs();
        System.out.printf("Taking absolute value of a big number number1:`%s` will get a big number number3:`%s`.%n",number1.toPlainString(),number3.toPlainString());
    }

    public static void printBigNumberWithScientificAnnotation(BigDecimal number1){
        System.out.printf("A big number number1:`%s` can be represented as `%s` with scientific annotation.%n",number1.toPlainString(),number1.toEngineeringString());
    }

    public static void printBigNumberWithoutScientificAnnotation(BigDecimal number1){
        System.out.printf("A big number number1:`%s` can be represented as `%s` without scientific annotation.%n",number1.toPlainString(),number1.toPlainString());
    }

    public static void printBigNumberPrecision(BigDecimal number1){
        System.out.printf("A big number number1:`%s` has the precision `%d`.%n",number1.toPlainString(),number1.precision());
    }
}
