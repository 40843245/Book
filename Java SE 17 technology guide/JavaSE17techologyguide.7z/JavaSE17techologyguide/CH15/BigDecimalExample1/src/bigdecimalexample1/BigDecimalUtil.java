package bigdecimalexample1;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class BigDecimalUtil {

    // method overloaded
    public static BigDecimal rounding(int number,int scale, RoundingMode roundingMode){
        var bigDecimal = new BigDecimal(String.valueOf(BigDecimal.valueOf((long)number)));
        return BigDecimalUtil.rounding(bigDecimal,scale,roundingMode);
    }

    // method overloaded
    public static BigDecimal rounding(long number,int scale, RoundingMode roundingMode){
        var bigDecimal = new BigDecimal(String.valueOf(BigDecimal.valueOf((long)number)));
        return BigDecimalUtil.rounding(bigDecimal,scale,roundingMode);
    }

    // method overloaded
    public static BigDecimal rounding(short number,int scale, RoundingMode roundingMode){
        var bigDecimal = new BigDecimal(String.valueOf(BigDecimal.valueOf((long)number)));
        return BigDecimalUtil.rounding(bigDecimal,scale,roundingMode);
    }

    // method overloaded
    public static BigDecimal rounding(float number,int scale, RoundingMode roundingMode){
        var bigDecimal = new BigDecimal(String.valueOf(BigDecimal.valueOf(number)));
        return BigDecimalUtil.rounding(bigDecimal,scale,roundingMode);
    }

    // method overloaded
    public static BigDecimal rounding(double number,int scale, RoundingMode roundingMode){
        var bigDecimal = new BigDecimal(String.valueOf(BigDecimal.valueOf(number)));
        return BigDecimalUtil.rounding(bigDecimal,scale,roundingMode);
    }

    // main method
    public static BigDecimal rounding(BigDecimal bigDecimal,int scale, RoundingMode roundingMode){
        return bigDecimal.setScale(scale,roundingMode);
    }
}
