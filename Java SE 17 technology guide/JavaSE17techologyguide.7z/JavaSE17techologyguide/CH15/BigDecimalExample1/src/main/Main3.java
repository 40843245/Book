package main;

import bigdecimalexample1.BigDecimalExample1;

import java.math.BigDecimal;

public class Main3 {
    public static void main(String[] args){
        BigDecimal number1 = new BigDecimal(String.valueOf(-25));
        BigDecimalExample1.printBigNumberPrecision(number1);
    }
}
