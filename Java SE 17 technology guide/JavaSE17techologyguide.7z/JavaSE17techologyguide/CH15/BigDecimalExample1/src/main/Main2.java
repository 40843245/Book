package main;

import bigdecimalexample1.BigDecimalExample1;

import java.math.BigDecimal;

public class Main2 {
    public static void main(String[] args){
        BigDecimal number1 = new BigDecimal(String.valueOf(-25));
        BigDecimal number2 = new BigDecimal(String.valueOf(33));

        BigDecimalExample1.printResultAfterAdding(number1,number2);
        BigDecimalExample1.printResultAfterSubtracting(number1,number2);
        BigDecimalExample1.printResultAfterMultiplying(number1,number2);
        BigDecimalExample1.printResultAfterPowing(number1,number2);
        BigDecimalExample1.printResultAfterDividingAndRemaining(number1,number2);
        BigDecimalExample1.printResultAfterAbsing(number1);
        BigDecimalExample1.printBigNumberWithScientificAnnotation(number1);
        BigDecimalExample1.printBigNumberWithoutScientificAnnotation(number1);

    }
}
