package main;

import bigdecimalexample1.BigDecimalExample1;

import java.math.RoundingMode;

public class Main {
    public static void main(String[] args){
        var integers = new int[]{
            0,
            1,
            2,
            3,
            -1,
            -2,
            -3
        };

        var floatNumbers = new float[]{
                0.0f,
                0.2f,
                0.5f,
                0.6f,
                1.0f,
                1.5f,
                2.0f,
                2.2f,
                2.5f,
                3.0f,
                -0.2f,
                -0.5f,
                -0.6f,
                -1.0f,
                -1.5f,
                -2.0f,
                -2.2f,
                -2.5f,
                -3.0f
        };

        var scales = new int[]{
                0,
                1,
                2,
                -1,
                -2
        };

        RoundingMode[] roundingModes = new RoundingMode[]{
                RoundingMode.CEILING,
                RoundingMode.FLOOR,
                RoundingMode.HALF_DOWN,
                RoundingMode.HALF_EVEN,
                RoundingMode.DOWN,
                RoundingMode.UP
        };

        for(var integer: integers){
            System.out.printf("---------- integer:`%d` ----------%n",integer);
            for(var scale: scales) {
                System.out.printf("---------- scale:`%d` ----------%n",scale);
                for(var roundingMode:roundingModes) {
                    System.out.printf("---------- Rounding Mode:`%s` ----------%n",roundingMode.toString());
                    BigDecimalExample1.printResultAfterRounding(integer, scale,roundingMode);
                }
            }
        }

        for(var floatNumber: floatNumbers){
            System.out.printf("---------- float number:`%f` ----------%n",floatNumber);
            for(var scale: scales) {
                System.out.printf("---------- scale:`%d` ----------%n",scale);
                for(var roundingMode:roundingModes) {
                    System.out.printf("---------- Rounding Mode:`%s` ----------%n",roundingMode.toString());
                    BigDecimalExample1.printResultAfterRounding(floatNumber, scale,roundingMode);
                }
            }
        }
    }
}
