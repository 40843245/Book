package download;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Download {
    public static void download(String[] args) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(args[0])).GET().build();
        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println(response.statusCode());
        System.out.println(response.body());
    }

    public static InputStream openStream(String uri){
        return HttpClient.newHttpClient().send(HttpRequest.newBuilder(URI.create(uri)).build(), HttpResponse.BodyHandlers.ofInputStream()).body();
    }
}
