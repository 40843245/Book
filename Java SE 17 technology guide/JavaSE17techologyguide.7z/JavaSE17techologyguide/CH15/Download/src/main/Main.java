package main;

import download.Download;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        Download.download(args);
    }
}
