package main;

import calenderdisplayer.CalenderDisplayer;

import java.util.Calendar;

public class Main {
    public static void main(String[] args) {
        Calendar calendarInst = Calendar.getInstance();
        CalenderDisplayer.printCalender(calendarInst);

        /*for (var i = 0; i <= 2000; i++) {
            System.out.printf("Is %dth year a leap year?`%b`.%n",i, CalenderDisplayer.isLeapYear(i));
        }*/
    }
}
