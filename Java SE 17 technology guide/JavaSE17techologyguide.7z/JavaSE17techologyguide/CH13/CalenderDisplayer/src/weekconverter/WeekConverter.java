package weekconverter;

public class WeekConverter {
    public static String getWeekOfDay(int weekOfDay){
        if(weekOfDay==0){
            return "一";
        }
        if(weekOfDay==1){
            return "二";
        }
        if(weekOfDay==2){
            return "三";
        }
        if(weekOfDay==3){
            return "四";
        }
        if(weekOfDay==4){
            return "五";
        }
        if(weekOfDay==5){
            return "六";
        }
        if(weekOfDay==6){
            return "日";
        }
        throw new IllegalArgumentException("The week of day must be on 1 to 7.");
    }
}
