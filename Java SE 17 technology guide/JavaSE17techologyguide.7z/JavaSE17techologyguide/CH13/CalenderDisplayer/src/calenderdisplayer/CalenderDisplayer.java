package calenderdisplayer;


import weekconverter.WeekConverter;

import java.time.chrono.MinguoChronology;
import java.time.chrono.MinguoDate;
import java.util.Calendar;
import java.util.Date;

public class CalenderDisplayer {

    private static int[] numOfDayInMonth = new int[]{
       31,28,31,30,31,30,31,31,30,31,30,31
    };

    public static void printCalender(Calendar calendar){
        StringBuilder text = new StringBuilder();
        Date date = calendar.getTime();
        var day = date.getDay();
        text.append("民國");
        text.append(" ");
        text.append(date.getYear());
        text.append(" ");
        text.append("年");
        text.append(" ");
        text.append(date.getMonth());
        text.append(" ");
        text.append("月");
        text.append(" ");
        text.append(day);
        text.append(" ");
        text.append("日");
        text.append(" ");
        text.append("週");
        text.append(WeekConverter.getWeekOfDay(day));
        text.append(" ");
        text.append("\n");
        text.append("\n");
        text.append(" ");
        text.append("日");
        text.append(" ");
        text.append("一");
        text.append(" ");
        text.append("二");
        text.append(" ");
        text.append("三");
        text.append(" ");
        text.append("四");
        text.append(" ");
        text.append("五");
        text.append(" ");
        text.append("六");
        text.append("\n");

        var remainderDayOfWeek = 7 - day;
        text.append(" ".repeat(remainderDayOfWeek*2));

        for (var i = 1; i <= day; i++) {
            text.append(" ");
            text.append(i);
            text.append(" ");
        }
        text.append("\n");
        text.append(" ");
        for (int i = day + 1,j = 1; i <= day + 14 ; i++,j++) {
            if(j==7){
                text.append("\n");
                text.append(" ");
                j = 0;
            }
            if(i<10){
                text.append(" ");
            }
            text.append(i);
            text.append(" ");
        }

        var numOfDay = CalenderDisplayer.numOfDayInMonth[date.getMonth()-1];
        for (int i = day + 14 + 1, j = 1 ; i <= numOfDay ; i++,j++) {
            if(j==7){
                text.append("\n");
                text.append(" ");
                j = 0;
            }
            text.append(i);
            text.append(" ");
        }
        System.out.println(text);
    }

    private static void updateNumOfDayInMonth(int year){
        boolean isLeapYear = CalenderDisplayer.isLeapYear(year);
        if(isLeapYear){
            CalenderDisplayer.numOfDayInMonth[1]=29;
        }
    }

    public static boolean isLeapYear(int year){
        return (year % 400 == 0) || ( (year % 100 != 0 ) && (year % 4 ==0) );
    }
}
