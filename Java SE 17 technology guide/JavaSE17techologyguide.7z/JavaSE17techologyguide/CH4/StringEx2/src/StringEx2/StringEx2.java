package StringEx2;

public class StringEx2 {
    public static void main(String[] args) {
        var str1 = "Ja" + "va";
        var str2 = "Java";

        System.out.println(str1==str2);

        System.out.println(str1.equals(str2));
    }
}
