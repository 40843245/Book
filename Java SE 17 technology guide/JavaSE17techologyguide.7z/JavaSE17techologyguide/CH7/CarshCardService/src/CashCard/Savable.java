package CashCard;

public interface Savable {
    void save(CashCard cashCard);
}
