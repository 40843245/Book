package main;

import client.Client;
import client.ClientEvent;
import client.ClientQueue;

public class Main2 {
    public static void main(String[] args) throws NoSuchMethodException {
        Client client1 = new Client("3306","client1");
        Client client2 = new Client("3307","client2");
        Client client3 = new Client("3308","client3");
        Client client4 = new Client("3309","client4");

        ClientEvent clientEvent1 = new ClientEvent(client1);
        ClientEvent clientEvent2 = new ClientEvent(client2);
        ClientEvent clientEvent3 = new ClientEvent(client3);
        ClientEvent clientEvent4 = new ClientEvent(client4);

        ClientQueue clientQueue = new ClientQueue();

        clientQueue.add(client1);
    }
}
