package client;

public class ClientAddedImpl {

}
