package client;

import java.util.ArrayList;

public class ClientQueue {
    private ArrayList<Client> clients = new ArrayList<>();
    private ArrayList<ClientListener> listeners = new ArrayList<>();

    public void addClientListener(ClientListener listener){
        this.listeners.add(listener);
    }

    public void add(Client client) throws NoSuchMethodException {
        //this.clients.add(client);
        var annotatedClass = new ClientLogger().getClass().getMethod("clientAdded");
        System.out.println(annotatedClass);

        var event = new ClientEvent(client);
        for (var listener: listeners) {
            //var annotation = listener.getClass().getAnnotatio;
            //listener.clientAdded(event);
        }
    }

    public void remove(Client client){
        this.clients.remove(client);
        var event = new ClientEvent(client);
        for (var listener: listeners) {
            listener.clientRemoved(event);
        }
    }
}
