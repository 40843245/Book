package client;

public class ClientLogger implements ClientListener {

    @Override
    @ClientAdded
    public void clientAdded(ClientEvent event) {
        System.out.printf("%s added.%n",event.getIp());
    }

    @Override
    @ClientRemoved
    public void clientRemoved(ClientEvent event) {
        System.out.printf("%s removed.%n",event.getIp());
    }
}
