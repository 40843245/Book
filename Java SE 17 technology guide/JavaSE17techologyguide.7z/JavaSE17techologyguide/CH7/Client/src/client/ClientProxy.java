package client;

public class ClientProxy {

}
